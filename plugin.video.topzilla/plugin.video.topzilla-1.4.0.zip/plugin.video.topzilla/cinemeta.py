# -*- coding: utf-8 -*-
# TopZilla — Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/espatv)
# Consulta el archivo LICENSE para mas detalles.
import sys
import json
import os
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs
import requests
import core_settings

_TOP_BASE    = "https://cinemeta-catalogs.strem.io/top/catalog/movie/top"
_POSTER_BASE = "https://images.metahub.space/poster/medium"
_CM_TTL      = 6 * 3600
_CM_MIN      = 3
_TOP_SKIPS   = (0, 50, 100, 150)

_CM_GENRES = [
    ("Accion",          "Action"),
    ("Aventura",        "Adventure"),
    ("Animacion",       "Animation"),
    ("Comedia",         "Comedy"),
    ("Crimen",          "Crime"),
    ("Documental",      "Documentary"),
    ("Drama",           "Drama"),
    ("Familia",         "Family"),
    ("Fantasia",        "Fantasy"),
    ("Historia",        "History"),
    ("Terror",          "Horror"),
    ("Musica",          "Music"),
    ("Misterio",        "Mystery"),
    ("Romance",         "Romance"),
    ("Ciencia Ficcion", "Sci-Fi"),
    ("Thriller",        "Thriller"),
    ("Belica",          "War"),
    ("Western",         "Western"),
]


def _u(**kwargs):
    return core_settings.make_url(**kwargs)

def _handle():
    return int(sys.argv[1])

def _cache_path():
    profile = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    return os.path.join(profile, 'topzilla_cinemeta_cache.json')


def _load_cache():
    empty = {"top": {}, "genres": {}}
    try:
        path = _cache_path()
        if not os.path.exists(path):
            return empty
        with open(path, 'r', encoding='utf-8') as fh:
            data = json.load(fh)
        for key in empty:
            if not isinstance(data.get(key), dict):
                data[key] = {}
        return data
    except Exception as e:
        xbmc.log(f"[TopZilla] cinemeta cache load error: {e}", xbmc.LOGWARNING)
        return empty


def _save_cache(data):
    try:
        path = _cache_path()
        os.makedirs(os.path.dirname(path), exist_ok=True)
        tmp = path + '.tmp'
        with open(tmp, 'w', encoding='utf-8') as fh:
            json.dump(data, fh, ensure_ascii=False)
        os.replace(tmp, path)
    except Exception as e:
        xbmc.log(f"[TopZilla] cinemeta cache save error: {e}", xbmc.LOGWARNING)


def _cache_fresh(cache):
    c = cache.get("top", {})
    return bool(c.get("films")) and (time.time() - c.get("fetched_at", 0)) < _CM_TTL


def _meta_to_film(m):
    imdb_id = str(m.get("imdb_id") or m.get("id") or "")
    name = m.get("name", "").strip()
    if not name:
        return None
    poster = f"{_POSTER_BASE}/{imdb_id}/img" if imdb_id else m.get("poster", "")
    year = str(m.get("year", ""))
    rating = m.get("imdbRating") or ""
    runtime_str = m.get("runtime") or ""
    runtime = 0
    if isinstance(runtime_str, str):
        digits = "".join(c for c in runtime_str if c.isdigit())
        if digits:
            try:
                runtime = int(digits)
            except ValueError:
                runtime = 0
    director = m.get("director") or ""
    if isinstance(director, list):
        director = ", ".join(director[:2])
    return {
        "id":       imdb_id,
        "title":    name,
        "poster":   poster,
        "year":     year,
        "genre":    ", ".join(m.get("genres") or m.get("genre") or []),
        "plot":     m.get("description", ""),
        "rating":   rating,
        "runtime":  runtime,
        "director": director,
    }


def _fetch_catalog_url(url, label):
    try:
        r = requests.get(url, timeout=12)
        xbmc.log(f"[TopZilla] cinemeta {label} -> {r.status_code}", xbmc.LOGINFO)
        if r.status_code != 200:
            return []
        return r.json().get("metas", []) or []
    except Exception as e:
        xbmc.log(f"[TopZilla] cinemeta {label} error: {e}", xbmc.LOGERROR)
        return []


def _fetch_top():
    try:
        urls = [(skip, f"{_TOP_BASE}/skip={skip}.json") for skip in _TOP_SKIPS]
        results = {}
        with ThreadPoolExecutor(max_workers=len(urls)) as ex:
            future_map = {ex.submit(_fetch_catalog_url, url, f"skip={skip}"): skip for skip, url in urls}
            for fut in as_completed(future_map):
                results[future_map[fut]] = fut.result()

        films = []
        seen = set()
        for skip in _TOP_SKIPS:
            for m in results.get(skip, []):
                f = _meta_to_film(m)
                if not f:
                    continue
                key = f["id"] or f["title"].lower()
                if key in seen:
                    continue
                seen.add(key)
                films.append(f)

        if len(films) < _CM_MIN:
            xbmc.log(f"[TopZilla] cinemeta resultado sospechoso ({len(films)} films), ignorando", xbmc.LOGWARNING)
            return None
        xbmc.log(f"[TopZilla] cinemeta {len(films)} películas en top", xbmc.LOGINFO)
        return films
    except Exception as e:
        xbmc.log(f"[TopZilla] cinemeta fetch error: {e}", xbmc.LOGERROR)
        return None


def _fetch_genre(slug):
    try:
        url = f"{_TOP_BASE}/genre={slug}.json"
        metas = _fetch_catalog_url(url, f"genre={slug}")
        films = []
        seen = set()
        for m in metas:
            f = _meta_to_film(m)
            if not f:
                continue
            key = f["id"] or f["title"].lower()
            if key in seen:
                continue
            seen.add(key)
            films.append(f)
        if len(films) < _CM_MIN:
            xbmc.log(f"[TopZilla] cinemeta genre {slug} sospechoso ({len(films)} films)", xbmc.LOGWARNING)
            return None
        xbmc.log(f"[TopZilla] cinemeta genre {slug}: {len(films)} películas", xbmc.LOGINFO)
        return films
    except Exception as e:
        xbmc.log(f"[TopZilla] cinemeta genre error: {e}", xbmc.LOGERROR)
        return None


def _get_top_films():
    cache = _load_cache()

    if _cache_fresh(cache):
        films = cache["top"]["films"]
        xbmc.log(f"[TopZilla] cinemeta top desde caché ({len(films)} títulos)", xbmc.LOGINFO)
        return films

    fetched = _fetch_top()
    if fetched is not None:
        films = fetched
        cache["top"] = {"fetched_at": time.time(), "films": films}
    elif cache.get("top", {}).get("films"):
        films = cache["top"]["films"]
        xbmc.log("[TopZilla] cinemeta inaccesible, usando caché caducada", xbmc.LOGWARNING)
    else:
        return []

    _save_cache(cache)
    return films


def show_top():
    import metadata_enricher as me

    films = _get_top_films()
    if not films:
        xbmcgui.Dialog().notification("TopZilla", "No se pudo cargar Cinemeta", xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.endOfDirectory(_handle())
        return

    af = core_settings.addon_fanart()

    auto_fetch = core_settings._auto_fetch_enabled()
    _bold  = core_settings.get_acc_force_bold()
    _strip = core_settings.get_acc_strip_symbols()
    _color = core_settings.get_acc_color_mode()

    if not auto_fetch:
        first_imdb = films[0].get('id') if films else None
        has_meta = bool(me.enrich(imdb_id=first_imdb, use_cache_only=True)) if first_imdb else False
        if not has_meta:
            li = xbmcgui.ListItem(label=core_settings.apply_label("[COLOR yellow][B]Descargar metadatos completos[/B][/COLOR]", bold=_bold, strip=_strip, color_mode=_color))
            li.setArt({'icon': 'DefaultAddonService.png', 'fanart': core_settings.addon_fanart()})
            li.setInfo('video', {'plot': "Descarga en español: sinopsis, actores y director de ~190 películas.\nSe guarda permanentemente (30 días)."})
            xbmcplugin.addDirectoryItem(handle=_handle(), url=_u(action="cinemeta_cache_meta"), listitem=li, isFolder=False)
        else:
            li = xbmcgui.ListItem(label=core_settings.apply_label("[COLOR red][B]Borrar metadatos descargados[/B][/COLOR]", bold=_bold, strip=_strip, color_mode=_color))
            li.setArt({'icon': 'DefaultIconError.png', 'fanart': core_settings.addon_fanart()})
            li.setInfo('video', {'plot': "Elimina los metadatos guardados para que vuelva a cargar solo con datos básicos."})
            xbmcplugin.addDirectoryItem(handle=_handle(), url=_u(action="cinemeta_clear_meta"), listitem=li, isFolder=False)

    import context_menu, movie_ref
    for f in films:
        year_int = int(f['year']) if f.get('year', '').isdigit() else 0
        label = "[B]{0}[/B]".format("{0} ({1})".format(f['title'], year_int) if year_int else f['title'])
        li = xbmcgui.ListItem(label=core_settings.apply_label(label, bold=_bold, strip=_strip, color_mode=_color))

        meta = me.enrich(imdb_id=f.get('id'), title=f['title'], year=year_int, use_cache_only=not auto_fetch)
        if meta:
            me.apply_to_listitem(li, meta, addon_fanart=af)
            poster = meta.get('poster') or f['poster']
        else:
            li.setArt({'icon': 'DefaultVideo.png', 'thumb': f['poster'], 'poster': f['poster'], 'fanart': af})
            header = me.build_plot_header(
                f.get('rating'), f.get('genre'),
                runtime=f.get('runtime'), director=f.get('director'),
            )
            li.setInfo('video', {
                'title':     f['title'],
                'year':      year_int,
                'genre':     f.get('genre', ''),
                'plot':      header + f.get('plot', ''),
                'mediatype': 'movie',
            })
            poster = f['poster']

        tmdb_id = (meta or {}).get('ids', {}).get('tmdb') if meta else None
        plot = meta.get('overview', '') if meta else f.get('plot', '')
        ref = movie_ref.make_ref(
            title=f['title'], year=year_int,
            tmdb_id=tmdb_id, imdb_id=f.get('id'), poster=poster,
            media_type='movie', source='cinemeta', plot=plot,
        )
        context_menu.attach(li, ref)
        li.setProperty('IsPlayable', 'false')
        xbmcplugin.addDirectoryItem(handle=_handle(), url=context_menu.build_play_url(ref), listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(_handle())


def cache_meta():
    import metadata_enricher as me

    films = _get_top_films()
    if not films:
        xbmcgui.Dialog().notification("TopZilla", "No hay películas para descargar", xbmcgui.NOTIFICATION_ERROR)
        return

    items = [
        {'imdb_id': f.get('id'), 'title': f['title'],
         'year': int(f['year']) if f.get('year', '').isdigit() else None,
         'media_type': 'movie'}
        for f in films
    ]

    pDialog = xbmcgui.DialogProgress()
    pDialog.create("TopZilla", "Descargando metadatos Cinemeta...")
    try:
        count = me.batch_fetch_with_progress(items, pDialog)
    finally:
        pDialog.close()

    xbmcgui.Dialog().notification(
        "TopZilla",
        "Metadatos guardados: {0}/{1}".format(count, len(items)),
        xbmcgui.NOTIFICATION_INFO,
    )
    xbmc.executebuiltin("Container.Refresh")


def clear_meta():
    import metadata_enricher as me

    films = _get_top_films()
    imdb_ids = [f.get('id') for f in films if f.get('id')]
    me.delete_by_imdb_ids(imdb_ids)
    xbmcgui.Dialog().notification("TopZilla", "Metadatos de Cinemeta eliminados", xbmcgui.NOTIFICATION_INFO)
    xbmc.executebuiltin("Container.Refresh")


def _genre_fresh(cache, slug):
    g = cache.get("genres", {}).get(slug, {})
    return bool(g.get("films")) and (time.time() - g.get("fetched_at", 0)) < _CM_TTL


def _get_genre_films(slug):
    cache = _load_cache()
    if _genre_fresh(cache, slug):
        films = cache["genres"][slug]["films"]
        xbmc.log(f"[TopZilla] cinemeta genre {slug} desde caché ({len(films)} títulos)", xbmc.LOGINFO)
        return films
    fetched = _fetch_genre(slug)
    if fetched is not None:
        films = fetched
        cache.setdefault("genres", {})[slug] = {"fetched_at": time.time(), "films": films}
    elif cache.get("genres", {}).get(slug, {}).get("films"):
        films = cache["genres"][slug]["films"]
        xbmc.log(f"[TopZilla] cinemeta genre {slug} inaccesible, usando caché caducada", xbmc.LOGWARNING)
    else:
        return []
    _save_cache(cache)
    return films


def show_genres_menu():
    _bold  = core_settings.get_acc_force_bold()
    _strip = core_settings.get_acc_strip_symbols()
    _color = core_settings.get_acc_color_mode()
    af = core_settings.addon_fanart()
    for label, slug in _CM_GENRES:
        li = xbmcgui.ListItem(label=core_settings.apply_label("[B]{0}[/B]".format(label), bold=_bold, strip=_strip, color_mode=_color))
        li.setArt({'icon': 'DefaultVideoPlaylists.png', 'fanart': af})
        url = _u(action="cinemeta_genre", slug=slug)
        xbmcplugin.addDirectoryItem(handle=_handle(), url=url, listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(_handle())


def show_genre(slug):
    import metadata_enricher as me

    films = _get_genre_films(slug)
    if not films:
        xbmcgui.Dialog().notification("TopZilla", f"No se pudo cargar {slug}", xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.endOfDirectory(_handle())
        return

    af = core_settings.addon_fanart()
    auto_fetch = core_settings._auto_fetch_enabled()
    _bold  = core_settings.get_acc_force_bold()
    _strip = core_settings.get_acc_strip_symbols()
    _color = core_settings.get_acc_color_mode()

    import context_menu, movie_ref
    for f in films:
        year_int = int(f['year']) if f.get('year', '').isdigit() else 0
        label = "[B]{0}[/B]".format("{0} ({1})".format(f['title'], year_int) if year_int else f['title'])
        li = xbmcgui.ListItem(label=core_settings.apply_label(label, bold=_bold, strip=_strip, color_mode=_color))

        meta = me.enrich(imdb_id=f.get('id'), title=f['title'], year=year_int, use_cache_only=not auto_fetch)
        if meta:
            me.apply_to_listitem(li, meta, addon_fanart=af)
            poster = meta.get('poster') or f['poster']
        else:
            li.setArt({'icon': 'DefaultVideo.png', 'thumb': f['poster'], 'poster': f['poster'], 'fanart': af})
            header = me.build_plot_header(
                f.get('rating'), f.get('genre'),
                runtime=f.get('runtime'), director=f.get('director'),
            )
            li.setInfo('video', {
                'title':     f['title'],
                'year':      year_int,
                'genre':     f.get('genre', ''),
                'plot':      header + f.get('plot', ''),
                'mediatype': 'movie',
            })
            poster = f['poster']

        tmdb_id = (meta or {}).get('ids', {}).get('tmdb') if meta else None
        plot = meta.get('overview', '') if meta else f.get('plot', '')
        ref = movie_ref.make_ref(
            title=f['title'], year=year_int,
            tmdb_id=tmdb_id, imdb_id=f.get('id'), poster=poster,
            media_type='movie', source='cinemeta', plot=plot,
        )
        context_menu.attach(li, ref)
        li.setProperty('IsPlayable', 'false')
        xbmcplugin.addDirectoryItem(handle=_handle(), url=context_menu.build_play_url(ref), listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(_handle())
