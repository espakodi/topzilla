# -*- coding: utf-8 -*-
# TopZilla — Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/espatv)
# Consulta el archivo LICENSE para mas detalles.

"""
Universo EspaKodi
=================
Ventana informativa con enlaces a los proyectos relacionados,
canales de Telegram y contacto del desarrollador.
"""
import os
import xbmc
import xbmcgui
import xbmcaddon
import xbmcvfs

_ADDON_PATH = xbmcaddon.Addon().getAddonInfo("path")
_MEDIA = os.path.join(_ADDON_PATH, "resources", "media")
_TEX = os.path.join(_MEDIA, "white.png")
_TRANSP = os.path.join(_MEDIA, "transparent.png")
_FOCUS = os.path.join(_MEDIA, "focus.png")

W, H = 1280, 720
PW, PH = 600, 520
PX, PY = (W - PW) // 2, (H - PH) // 2


class UniversoDialog(xbmcgui.WindowDialog):
    """Diálogo con enlaces al ecosistema EspaKodi."""

    def __init__(self):
        super().__init__()
        self.url_map = {}
        self.all_buttons = []
        self.close_btn_id = -1
        self.reveal_btn_id = -1
        self.bg_img = None
        self.all_controls = []
        self._is_downloading = False
        self._build()

    def _mk_img(self, x, y, w, h, color, img=None):
        c = xbmcgui.ControlImage(x, y, w, h, img or _TEX, colorDiffuse=color)
        self._pending.append(c)
        self.all_controls.append(c)
        return c

    def _mk_lbl(self, x, y, w, h, text, font="font13", color="FFFFFFFF", align=0):
        c = xbmcgui.ControlLabel(
            x, y, w, h, text, font=font, textColor=color, alignment=align
        )
        self._pending.append(c)
        self.all_controls.append(c)
        return c

    def _mk_btn(self, x, y, w, h, text, tc="FFFFFFFF", fc="FFFFFFFF", align=0x04):
        c = xbmcgui.ControlButton(
            x, y, w, h, text,
            font="font12", textColor=tc, focusedColor=fc, alignment=align,
            noFocusTexture=_TRANSP, focusTexture=_FOCUS,
        )
        self._pending.append(c)
        self.all_controls.append(c)
        return c

    def _build(self):
        self._pending = []

        # Panel central semi-transparente
        self._mk_img(PX, PY, PW, PH, "D0111922")

        # Imagen easter egg precargada pero oculta
        _profile = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
        bg_path = os.path.join(_profile, 'tz.jpg')
        if os.path.exists(bg_path):
            self.bg_img = xbmcgui.ControlImage(PX, PY, PW, PH, bg_path, colorDiffuse='FFFFFFFF')
            self._pending.append(self.bg_img)

        self._mk_img(PX, PY, PW, 3, "FF3090FF")

        # el título actúa como botón — click activa el easter egg
        y = PY + 17
        reveal = xbmcgui.ControlButton(PX, y, PW, 25,
                          '[B]Universo EspaKodi[/B]',
                          font='font13', textColor='FF3090FF', focusedColor='FFFFFFFF', alignment=0x02,
                          noFocusTexture=_TRANSP, focusTexture=_FOCUS)
        self._pending.append(reveal)
        self.all_controls.append(reveal)
        self.all_buttons.append(reveal)
        y += 39
        self._mk_img(PX + 35, y, PW - 70, 1, "15FFFFFF")
        y += 16

        links = [
            ("FFFFD700", "Contacto", "https://t.me/rubensdfa1laberot/?direct"),
            (None, None, None),
            ("FF2AABEE", "Canal de Telegram", "https://t.me/espadaily"),
            ("FF2AABEE", "Chat EspaKodi", "https://t.me/espakodi"),
            (None, None, None),
            ("FFA0522D", "Web", "https://espatv.github.io"),
        ]

        self._link_buttons = []
        for color, label, url in links:
            if color is None:
                y += 6
                self._mk_img(PX + 35, y, PW - 70, 1, "15FFFFFF")
                y += 10
                continue

            self._mk_lbl(
                PX + 50, y, PW - 100, 24,
                "[B]{0}[/B]".format(label),
                font="font13", color=color, align=0x04
            )
            btn = xbmcgui.ControlButton(
                PX + 35, y, PW - 70, 24,
                "[B]" + (url or "").replace("https://", "") + "[/B]  ",
                font="font13", textColor="FFCCCCCC", focusedColor="FFFFFFFF",
                alignment=0x01 | 0x04,
                noFocusTexture=_TRANSP, focusTexture=_FOCUS,
            )
            self._pending.append(btn)
            self.all_controls.append(btn)
            self._link_buttons.append((btn, url))
            self.all_buttons.append(btn)
            y += 28

        y += 6
        self._mk_img(PX + 35, y, PW - 70, 1, "15FFFFFF")
        y += 15

        close = self._mk_btn(
            PX + (PW - 180) // 2, y, 180, 32,
            "[B]Cerrar[/B]", tc="FF888888", align=0x02 | 0x04,
        )
        self.all_buttons.append(close)

        self.addControls(self._pending)

        # Asignar IDs después del batch (solo disponibles tras addControls)
        self.reveal_btn_id = reveal.getId()
        self.close_btn_id = close.getId()
        for btn, url in self._link_buttons:
            self.url_map[btn.getId()] = url

        if self.bg_img:
            self.bg_img.setVisible(False)

        # Navegación circular entre botones
        for i in range(len(self.all_buttons)):
            b = self.all_buttons[i]
            if i > 0:
                b.controlUp(self.all_buttons[i - 1])
            if i < len(self.all_buttons) - 1:
                b.controlDown(self.all_buttons[i + 1])
        self.all_buttons[0].controlUp(self.all_buttons[-1])
        self.all_buttons[-1].controlDown(self.all_buttons[0])
        self.setFocus(self.all_buttons[0])

    def _handle_click(self, control_id):
        if control_id == self.close_btn_id:
            self.close()
            return
        if control_id == self.reveal_btn_id:
            if self._is_downloading:
                return
            if not self.bg_img:
                # Descarga bajo demanda para no penalizar el inicio
                self._is_downloading = True
                _profile = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
                if not os.path.exists(_profile):
                    os.makedirs(_profile)
                bg_path = os.path.join(_profile, 'tz.jpg')

                if not os.path.exists(bg_path):
                    xbmcgui.Dialog().notification("TopZilla", "Descargando recursos...", xbmcgui.NOTIFICATION_INFO, 1500)
                    try:
                        import requests
                        r = requests.get('https://github.com/fullstackcurso/Ruta-Fullstack/releases/download/Copia_Readme/tz.jpg', timeout=10)
                        if r.status_code == 200 and len(r.content) > 1000:
                            with open(bg_path, 'wb') as f:
                                f.write(r.content)
                    except Exception:
                        pass

                if os.path.exists(bg_path):
                    self.bg_img = xbmcgui.ControlImage(PX, PY, PW, PH, bg_path, colorDiffuse='FFFFFFFF')
                    self.addControl(self.bg_img)
                    self.bg_img.setVisible(False)

                self._is_downloading = False

            if self.bg_img:
                for c in self.all_controls:
                    c.setVisible(False)
                self.bg_img.setVisible(True)
                _profile = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
                _egg_path = os.path.join(_profile, 'egg_count.txt')
                try:
                    with open(_egg_path, 'r') as _f:
                        _egg_count = int(_f.read().strip())
                except Exception:
                    _egg_count = 0
                _egg_msgs = [
                    ("notif", "Fundado por RubénSDFA1laberot (mira de lejos y entorna los ojos)"),
                    ("notif", "Fundado por RubénSDFA1laberot (inclina la cabeza)"),
                    ("notif", "Fundado por RubénSDFA1laberot (cierra un ojo y luego el otro... ¿lo ves ya? si no, sigue dando)"),
                    ("ok", "Felicidades, has descubierto que no has descubierto nada.\n\nUn easter egg clásico no da premios. Da la satisfacción de haber llegado. La recompensa es haberte molestado en buscar.\n\nHay easter eggs que esconden secretos. Este esconde una firma.\n\nEste ASCII art es una firma autoral compuesta de varias fotografías fusionadas y alteradas. Composición de varios contribuidores del proyecto. Un rostro hecho de muchos. Entre eso y que se pierde mucha información por el camino, no se parece claramente a nadie. Quien sepa con qué fotografías, proceso y algoritmos se compuso podría determinar la atribución."),
                ]
                _kind, _msg = _egg_msgs[_egg_count % len(_egg_msgs)]
                if _kind == "ok":
                    xbmcgui.Dialog().ok("TopZilla", _msg)
                else:
                    xbmcgui.Dialog().notification("TopZilla", _msg, xbmcgui.NOTIFICATION_INFO, 3000)
                try:
                    with open(_egg_path, 'w') as _f:
                        _f.write(str(_egg_count + 1))
                except Exception:
                    pass
                import time as _t
                _t.sleep(3)
                self.bg_img.setVisible(False)
                for c in self.all_controls:
                    c.setVisible(True)
                self.bg_img.setVisible(False)
            return
        url = self.url_map.get(control_id)
        if url:
            try:
                if xbmc.getCondVisibility("System.Platform.Android"):
                    xbmc.executebuiltin(
                        'StartAndroidActivity("","android.intent.action.VIEW","","{0}")'.format(url)
                    )
                else:
                    import webbrowser
                    webbrowser.open(url)
                xbmcgui.Dialog().notification(
                    "TopZilla", "Abriendo enlace...",
                    xbmcgui.NOTIFICATION_INFO, 2000,
                )
            except Exception:
                xbmcgui.Dialog().ok(
                    "Enlace TopZilla",
                    "No se pudo abrir automáticamente. Abre esta URL:\n\n" + url,
                )

    def onAction(self, action):
        aid = action.getId()
        if aid in (10, 92, 110):
            self.close()
        elif aid in (7, 100, 101):
            self._handle_click(self.getFocusId())

    def onClick(self, controlId):
        self._handle_click(controlId)


def show():
    """Muestra el diálogo Universo EspaKodi."""
    bg = None
    try:
        import ascii_matrix
        bg = ascii_matrix.get_bg_dialog()
        if bg:
            bg.show()
    except Exception:
        pass
    dlg = UniversoDialog()
    dlg.doModal()
    if bg:
        try:
            bg.close()
        except Exception:
            pass
    del dlg
