# -*- coding: utf-8 -*-
# TopZilla — Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/espatv)
# Consulta el archivo LICENSE para mas detalles.
"""Cliente para OMDb (omdbapi.com).

Una sola petición JSON devuelve notas agregadas de IMDb, Rotten Tomatoes
y Metacritic.
"""
import json
import os
import time
import xbmc
import xbmcaddon
import xbmcvfs
import requests

_BASE = "https://www.omdbapi.com/"
_TIMEOUT = 10
_CACHE_TTL = 7 * 24 * 3600


def _cache_path():
    profile = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    os.makedirs(profile, exist_ok=True)
    return os.path.join(profile, 'topzilla_omdb_cache.json')


def _cache_load():
    p = _cache_path()
    if not os.path.exists(p):
        return {}
    try:
        with open(p, 'r', encoding='utf-8') as fh:
            data = json.load(fh)
        if not isinstance(data, dict):
            return {}
        now = time.time()
        return {k: v for k, v in data.items()
                if isinstance(v, dict) and (now - v.get('ts', 0)) < _CACHE_TTL}
    except (OSError, ValueError):
        return {}


def _cache_save(cache):
    try:
        p = _cache_path()
        tmp = p + '.tmp'
        with open(tmp, 'w', encoding='utf-8') as fh:
            json.dump(cache, fh, ensure_ascii=False)
        os.replace(tmp, p)
    except (OSError, TypeError, ValueError):
        pass


def _normalize_imdb_id(imdb_id):
    if not imdb_id:
        return None
    s = str(imdb_id).strip()
    if not s:
        return None
    return s if s.startswith('tt') else 'tt{0}'.format(s)


def _cache_key(imdb_id, title, year, media_type):
    if imdb_id:
        return "i:{0}".format(imdb_id)
    return "t:{0}|y:{1}|m:{2}".format(
        (title or '').lower().strip(), year or '', media_type or 'movie')


def fetch(api_key, imdb_id=None, title=None, year=None, media_type='movie'):
    """Devuelve dict OMDb o None si falla / no encontrada.

    Preferencia: imdb_id > title (+ year opcional).
    Errores específicos (clave inválida, cuota agotada) se devuelven como
    dict con `_topzilla_error` para que el llamante los distinga.
    """
    if not api_key or not isinstance(api_key, str):
        return None
    api_key = api_key.strip()
    if not api_key:
        return None

    norm_imdb = _normalize_imdb_id(imdb_id)
    if not norm_imdb and not title:
        return None

    cache = _cache_load()
    ckey = _cache_key(norm_imdb, title, year, media_type)
    cached = cache.get(ckey)
    if cached and isinstance(cached.get('data'), dict):
        return cached['data']

    params = {'apikey': api_key, 'r': 'json'}
    if norm_imdb:
        params['i'] = norm_imdb
    elif title:
        params['t'] = title.strip()
        if year is not None:
            try:
                y_int = int(year)
                if y_int > 0:
                    params['y'] = str(y_int)
            except (TypeError, ValueError):
                pass
    else:
        return None
    if media_type == 'show':
        params['type'] = 'series'
    elif media_type == 'movie':
        params['type'] = 'movie'

    try:
        r = requests.get(_BASE, params=params, timeout=_TIMEOUT)
    except requests.RequestException as e:
        xbmc.log("[TopZilla] OMDb network error: {0}".format(e), xbmc.LOGERROR)
        return {'_topzilla_error': 'network', 'Error': str(e)}
    if r.status_code != 200:
        xbmc.log("[TopZilla] OMDb HTTP {0}".format(r.status_code), xbmc.LOGWARNING)
        return {'_topzilla_error': 'http', 'Error': 'HTTP {0}'.format(r.status_code)}
    try:
        data = r.json()
    except ValueError:
        return None
    if not isinstance(data, dict):
        return None
    if data.get('Response') == 'False':
        err = (data.get('Error') or '').strip()
        xbmc.log("[TopZilla] OMDb response false: {0}".format(err), xbmc.LOGWARNING)
        if 'Invalid API key' in err:
            return {'_topzilla_error': 'invalid_key', 'Error': err}
        if 'limit reached' in err.lower():
            return {'_topzilla_error': 'rate_limit', 'Error': err}
        return None

    cache[ckey] = {'ts': time.time(), 'data': data}
    _cache_save(cache)
    return data


def validate_key(key, timeout=6):
    """Devuelve True si OMDb acepta la clave, False si la rechaza, None si no se pudo verificar."""
    if not isinstance(key, str) or not key.strip():
        return False
    try:
        r = requests.get(_BASE,
                         params={'apikey': key.strip(), 'i': 'tt0111161'},
                         timeout=timeout)
        if r.status_code == 200:
            try:
                data = r.json()
                if data.get('Response') == 'True':
                    return True
                if 'Invalid API key' in (data.get('Error') or ''):
                    return False
            except ValueError:
                return None
        if r.status_code in (401, 403):
            return False
    except Exception:
        pass
    return None
