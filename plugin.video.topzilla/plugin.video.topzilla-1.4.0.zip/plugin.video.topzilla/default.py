# -*- coding: utf-8 -*-
# TopZilla — Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/espatv)
# Consulta el archivo LICENSE para mas detalles.
import difflib
import json
import os
import re
import sys
import urllib.error
import urllib.parse
import xml.etree.ElementTree as ET

import requests

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

import core_settings
import stats


def _u(**kwargs):
    return core_settings.make_url(**kwargs)


def _mi(filename):
    return os.path.join(xbmcaddon.Addon().getAddonInfo('path'), 'resources', 'media', filename)


def _human_size(b):
    for unit in ('B', 'KB', 'MB', 'GB'):
        if b < 1024:
            return "{0:.1f} {1}".format(b, unit)
        b /= 1024
    return "{0:.1f} TB".format(b)


_ACC_COLOR_NAMES = {
    'none':        'Sin modificar (colores originales)',
    'white':       'Texto blanco (todos los colores → blanco)',
    'daltonic_rg': 'Daltónico rojo-verde (deuteranopia/protanopia)',
    'daltonic_by': 'Daltónico azul-amarillo (tritanopia)',
    'hc_dark':     'Alto contraste — fondo oscuro (amarillo)',
    'hc_light':    'Alto contraste — fondo claro (negro)',
}
_ACC_COLOR_PLOTS = {
    'none':        "Los textos aparecen con los colores originales del addon.",
    'white':       "Todos los textos de color se muestran en blanco.\nMáxima legibilidad sobre fondos oscuros.",
    'daltonic_rg': "Optimizado para daltonismo rojo-verde (deuteranopia o protanopia).\nLos rojos pasan a naranja y los verdes a cian.",
    'daltonic_by': "Optimizado para daltonismo azul-amarillo (tritanopia).\nLos amarillos pasan a magenta y los azules/cian a rojo.",
    'hc_dark':     "Alto contraste para skins con fondo oscuro.\nTodo el texto de color se muestra en amarillo, excepto las acciones destructivas (rojo).",
    'hc_light':    "Alto contraste para skins con fondo claro.\nTodo el texto de color se muestra en negro, excepto las acciones destructivas (rojo).",
}


# Menú principal

def _main_menu():
    h = int(sys.argv[1])

    items = [
        ("Buscar",                      "busqueda.png",        "search_menu",          True,  "Busca por título en los tops cargados (FilmAffinity, SensaCine, Cinemeta, TMDB, Históricas) o directamente en YouTube y Dailymotion."),
        ("Mi Biblioteca",               "mi_biblioteca.png",       "my_library_menu",  True,  "Tus favoritos, categorías personales e historiales de visionado y navegación."),
        ("Trakt.tv",                    "cat_trakt.png",       "trakt_root",           True,  "Listas públicas importadas desde Trakt.tv."),
        ("Mejores Películas",           "cat_pelis_top.png",   "filmaffinity_menu",    True,  "Top de películas y series por género, con portadas y títulos en español."),
        ("FilmAffinity",                "cat_filmaffinity.png","filmaffinity_submenu", True,  "En cines y top valoradas según FilmAffinity."),
        ("SensaCine",                   "cat_sensacine.png",   "sensacine_submenu",    True,  "Cartelera y estrenos en cines según SensaCine."),
        ("Cinemeta",                    "cat_cinemeta.png",    "cinemeta_submenu",     True,  "Top y géneros según Cinemeta/Stremio."),
        ("Rankings de TMDB",            "cat_pelis_top.png",   "tmdb_lists_menu",      True,  "Rankings oficiales de TMDB: populares, tendencias, mejor valoradas y más."),
        ("Top Películas de la Historia","cat_peliculas.png",   "top_movies",           True,  "Las ~130 mejores películas de todos los tiempos con sinopsis, director y nota IMDb."),
        ("Ganadoras del Oscar",         "oscar.png",            "oscar_movies",         True,  "Todas las ganadoras del Oscar a Mejor Película desde 1939 hasta hoy, ordenadas por año de ceremonia con sinopsis, director y nota IMDb."),
        ("Opciones",                    "opciones.png",        "options_menu",         True,  "Ajustes, accesibilidad visual, backup y limpieza."),
        ("EspaKodi e Información",      "info.png",            "info_menu",            True,  "Universo EspaKodi, versión, términos y avisos."),
    ]

    _bold = core_settings.get_acc_force_bold()
    _strip = core_settings.get_acc_strip_symbols()
    _color = core_settings.get_acc_color_mode()
    _fanart = core_settings.addon_fanart()
    for label, icon, action, is_folder, plot in items:
        li = xbmcgui.ListItem(label=core_settings.apply_label("[B]{0}[/B]".format(label), bold=_bold, strip=_strip, color_mode=_color))
        icon_path = _mi(icon) if not icon.startswith('Default') else icon
        li.setArt({'icon': icon_path, 'fanart': _fanart})
        li.setInfo('video', {'plot': plot})
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action=action), listitem=li, isFolder=is_folder)

    xbmcplugin.endOfDirectory(h, cacheToDisc=False)


def _my_library_menu():
    h = int(sys.argv[1])
    _bold  = core_settings.get_acc_force_bold()
    _strip = core_settings.get_acc_strip_symbols()
    _color = core_settings.get_acc_color_mode()

    items = [
        ("Mis Favoritos",           "favoritos.png",      "favorites_menu",          True, "Tus películas y series marcadas como favoritas."),
        ("Mis Categorías",          "DefaultPlaylist.png", "categories_menu",         True, "Tus colecciones personalizadas de películas."),
        ("Historial de Visionado",  "hist_visionado.png", "watch_history_menu",      True, "Películas y series que has marcado como vistas."),
        ("Historial de Navegación", "historial.png",      "navigation_history_menu", True, "Películas que has visitado recientemente."),
    ]
    for label, icon, action, is_folder, plot in items:
        li = xbmcgui.ListItem(label=core_settings.apply_label("[B]{0}[/B]".format(label), bold=_bold, strip=_strip, color_mode=_color))
        icon_path = icon if icon.startswith('Default') else _mi(icon)
        li.setArt({'icon': icon_path, 'fanart': core_settings.addon_fanart()})
        li.setInfo('video', {'plot': plot})
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action=action), listitem=li, isFolder=is_folder)

    xbmcplugin.endOfDirectory(h, cacheToDisc=False)


# EspaKodi e Información

def info_menu():
    h = int(sys.argv[1])
    _bold  = core_settings.get_acc_force_bold()
    _strip = core_settings.get_acc_strip_symbols()
    _color = core_settings.get_acc_color_mode()
    af = core_settings.addon_fanart()

    li = xbmcgui.ListItem(label=core_settings.apply_label(
        "[COLOR skyblue][B]Universo EspaKodi[/B][/COLOR]", bold=_bold, strip=_strip, color_mode=_color))
    li.setArt({'icon': _mi('info_universo.png'), 'fanart': af})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="show_universo"), listitem=li, isFolder=False)

    try:
        ver = xbmcaddon.Addon().getAddonInfo("version") or "?.?.?"
    except Exception:
        ver = "?.?.?"
    li = xbmcgui.ListItem(label=core_settings.apply_label(
        "[B]Versión {0}[/B]".format(ver), bold=_bold, strip=_strip, color_mode=_color))
    li.setArt({'icon': _mi('info_version.png'), 'fanart': af})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="noop"), listitem=li, isFolder=False)

    _ek_logo = _mi('espakodi_logo.jpg')
    _ek_icon = _ek_logo if os.path.exists(_ek_logo) else _mi('descargas.png')
    li = xbmcgui.ListItem(label=core_settings.apply_label(
        "[COLOR gold][B]EspaKodi Addons[/B][/COLOR]", bold=_bold, strip=_strip, color_mode=_color))
    li.setArt({'icon': _ek_icon, 'fanart': af})
    li.setInfo('video', {'plot': "Instala y gestiona todos los addons del ecosistema EspaKodi: EspaTV, EspaDaily, AtresDaily, LoioLog, Flow FavManager, StreamNinja."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="espakodi_addons_menu"), listitem=li, isFolder=True)

    li = xbmcgui.ListItem(label=core_settings.apply_label(
        "[COLOR yellow][B]La VPN puede causar fallos o ser necesaria[/B][/COLOR] — Algunos servidores bloquean VPNs (desactívala si algo no carga). En Dailymotion puede ocurrir lo contrario, si no carga prueba activando la VPN.",
        bold=_bold, strip=_strip, color_mode=_color))
    li.setArt({'icon': _mi('info_vpn.png'), 'fanart': af})
    li.setInfo('video', {'plot': "Algunos servidores bloquean VPNs (desactívala si algo no carga). En Dailymotion puede ocurrir lo contrario, si no carga prueba activando la VPN."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="vpn_info"), listitem=li, isFolder=False)

    li = xbmcgui.ListItem(label=core_settings.apply_label(
        "[COLOR lightgreen][B]Próximamente: más países e idiomas[/B][/COLOR] — Este addon se adaptará a más países y contará con más idiomas en futuras versiones.",
        bold=_bold, strip=_strip, color_mode=_color))
    li.setArt({'icon': _mi('adv_idioma.png'), 'fanart': af})
    li.setInfo('video', {'plot': "Este addon se adaptará a más países y contará con más idiomas en futuras versiones."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="future_i18n_info"), listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(h)


def _info():
    t = (
        "[B]AVISO LEGAL Y TÉCNICO IMPORTANTE:[/B]\n\n"

        "[B]1. Gratuito y sin ánimo de lucro:[/B]\n"
        "Este addon es completamente GRATUITO y siempre lo será. Si alguien te lo ha vendido, te han estafado. Cualquier etiqueta tipo \"Premium\" o equivalente hace referencia a la suscripción de la plataforma de origen; no a este addon.\n\n"

        "[B]2. Responsabilidad del Usuario:[/B]\n"
        "El desarrollador no tiene control sobre los resultados encontrados en servidores externos. El usuario es el único responsable de verificar la legalidad del acceso a dichos contenidos según las leyes de su país de residencia. Este addon se proporciona \"tal cual\", sin garantías de ningún tipo.\n\n"

        "[B]3. No Afiliación:[/B]\n"
        "Este proyecto es independiente. NO tiene ninguna afiliación, acuerdo ni vinculación con FilmAffinity, SensaCine, TMDB, Trakt, Cinemeta, ni con ninguna otra plataforma o entidad oficial. Las marcas comerciales se utilizan con fin únicamente descriptivo para organizar los menús de búsqueda.\n\n"

        "[B]4. Naturaleza Técnica (Agregador de Búsqueda):[/B]\n"
        "Este software actúa exclusivamente como una herramienta de automatización. NO contiene, aloja ni sube contenido protegido.\n"
        "• El addon nunca interactúa, descifra ni elude la seguridad de servidores de terceros.\n"
        "• Funciona realizando búsquedas de texto en servidores públicos de terceros, mostrando resultados que ya son accesibles públicamente en cualquier navegador web.\n\n"

        "[B]5. Propósito:[/B]\n"
        "Proyecto amateur. Sin publicidad ni recolección de hábitos de uso.\n\n"

        "[B]Contacto y Retirada:[/B]\n"
        "Si usted es titular de derechos y considera que este software le perjudica, puede solicitar la retirada de funcionalidad relacionada a través de los canales indicados en el repositorio oficial.\n\n"

        "[B]¿Qué puedo encontrar?[/B]\n"
        "El addon intenta filtrar los resultados con la mayor precisión posible, pero la precisión depende totalmente del contenido disponible públicamente en ese momento.\n"
        "• A veces solo aparecerán tráilers, resúmenes o clips.\n"
        "• En ocasiones pueden aparecer resultados solo relacionados o similares.\n"
        "El addon NO garantiza qué resultados aparecen, ya que depende exclusivamente de lo que otros usuarios hayan compartido en la red."
    )
    xbmcgui.Dialog().textviewer("Información de TopZilla", t)


def _options_menu():
    h = int(sys.argv[1])
    _bold  = core_settings.get_acc_force_bold()
    _strip = core_settings.get_acc_strip_symbols()
    _color = core_settings.get_acc_color_mode()

    auto = core_settings._auto_fetch_enabled()
    auto_tag = core_settings.state_tag(auto)
    li = xbmcgui.ListItem(label=core_settings.apply_label(
        "[B]Enriquecer metadatos con TMDB[/B] (no siempre es lo mejor)  {0}".format(auto_tag), bold=_bold, strip=_strip, color_mode=_color))
    li.setArt({'icon': _mi('adv_busqueda.png'), 'fanart': core_settings.addon_fanart()})
    li.setInfo('video', {'plot': "Consulta TMDB al navegar para completar lo que ya trae cada fuente. Añade sinopsis en español, géneros, reparto con fotos y carátulas de mayor calidad (úsalo solo si lo que ves no te convence, no siempre es lo mejor).\n\nLa principal ventaja es obtener datos en español cuando la fuente original carece de ellos o los tiene en otro idioma.\n\nLos datos se guardan en caché 30 días; solo se hacen peticiones nuevas la primera vez que se visita cada título.\n\n[COLOR blue][I]Pulsa para activar/desactivar.[/I][/COLOR]"})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="toggle_auto_fetch"), listitem=li, isFolder=False)

    if xbmc.getCondVisibility("System.HasAddon(plugin.video.espadaily)"):
        _eda_on = core_settings._espadaily_integration_enabled()
        _eda_tag = core_settings.state_tag(_eda_on)
        li = xbmcgui.ListItem(label=core_settings.apply_label(
            "[B]Buscar en EspaDaily[/B]  {0}".format(_eda_tag),
            bold=_bold, strip=_strip, color_mode=_color))
        li.setArt({'icon': _mi('adv_busqueda.png'), 'fanart': core_settings.addon_fanart()})
        li.setInfo('video', {'plot': (
            _ESPADAILY_INTRO_TEXT
            + "\n\n[COLOR blue][I]Pulsa para activar/desactivar.[/I][/COLOR]")})
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action="toggle_espadaily_integration"),
                                     listitem=li, isFolder=False)

    ctx = core_settings._show_context_menu_enabled()
    ctx_tag = core_settings.state_tag(ctx)
    li = xbmcgui.ListItem(label=core_settings.apply_label(
        "[B]Menú contextual global[/B]  {0}".format(ctx_tag), bold=_bold, strip=_strip, color_mode=_color))
    li.setArt({'icon': _mi('adv_idioma.png'), 'fanart': core_settings.addon_fanart()})
    li.setInfo('video', {'plot': "Inserta «Añadir a Favoritos (TopZilla)» en el menú contextual de casi cualquier película o serie en Kodi para ver su ficha en TopZilla. Permite guardarlo en tus Favoritos sin abrir antes TopZilla. El menú contextual se abre con clic derecho, manteniendo pulsado en pantallas táctiles o con el botón de menú del mando.\n\nCuando ya hayas visto ese título en TopZilla, la carátula y la sinopsis se rellenan desde la caché local sin tocar la red. Si el título no está en la caché y tienes activado «Enriquecer metadatos con TMDB», se hará una consulta a TMDB y el resultado quedará guardado para los siguientes accesos.\n\n[COLOR blue][I]Pulsa para activar/desactivar.[/I][/COLOR]"})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="toggle_show_context_menu"), listitem=li, isFolder=False)

    ctx_vc = core_settings._show_context_menu_view_card_enabled()
    ctx_vc_tag = core_settings.state_tag(ctx_vc)
    li = xbmcgui.ListItem(label=core_settings.apply_label(
        "[B]Ver ficha desde menú contextual global[/B]  {0}".format(ctx_vc_tag), bold=_bold, strip=_strip, color_mode=_color))
    li.setArt({'icon': _mi('adv_idioma.png'), 'fanart': core_settings.addon_fanart()})
    li.setInfo('video', {'plot': "Inserta «Ver ficha (TopZilla)» en el menú contextual de casi cualquier película o serie en Kodi. Abre directamente la ficha nativa de TopZilla (el diálogo con «¿Dónde verla en España?», YouTube, Dailymotion, Wikipedia, ficha completa…) sobre el título seleccionado, sin necesidad de añadirlo antes a Favoritos.\n\nLos títulos abiertos por esta vía [B]no[/B] se guardan en el Historial de navegación de TopZilla, ya que provienen de fuentes externas al addon.\n\n[COLOR blue][I]Pulsa para activar/desactivar.[/I][/COLOR]"})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="toggle_show_context_menu_view_card"), listitem=li, isFolder=False)

    li = xbmcgui.ListItem(label=core_settings.apply_label("[B]Fanart de fondo[/B]", bold=_bold, strip=_strip, color_mode=_color))
    li.setArt({'icon': _mi('adv_fanart.png'), 'fanart': core_settings.addon_fanart()})
    li.setInfo('video', {'plot': "Controla la imagen de fondo que se muestra en los menús del addon.\n\nPuedes usar la imagen del propio addon, una imagen tuya o desactivarlo por completo."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="fanart_menu"), listitem=li, isFolder=True)

    li = xbmcgui.ListItem(label=core_settings.apply_label("[B]Claves API[/B]", bold=_bold, strip=_strip, color_mode=_color))
    li.setArt({'icon': _mi('adv_api_key.png'), 'fanart': core_settings.addon_fanart()})
    li.setInfo('video', {'plot': "Configura tus claves API de TMDB y Trakt para mayor velocidad y estabilidad."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="api_keys_menu"), listitem=li, isFolder=True)

    li = xbmcgui.ListItem(label=core_settings.apply_label("[B]Accesibilidad[/B]", bold=_bold, strip=_strip, color_mode=_color))
    li.setArt({'icon': _mi('adv_accesibilidad.png'), 'fanart': core_settings.addon_fanart()})
    li.setInfo('video', {'plot': "Opciones de accesibilidad visual: modo de color, negrita forzada y sustitución de símbolos.\n\nAdapta la apariencia del addon para distintas necesidades visuales (daltonismo, alto contraste, etc.)."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="accessibility_menu"), listitem=li, isFolder=True)

    li = xbmcgui.ListItem(label=core_settings.apply_label("[B]Backup y restauración[/B]", bold=_bold, strip=_strip, color_mode=_color))
    li.setArt({'icon': _mi('adv_backup.png'), 'fanart': core_settings.addon_fanart()})
    li.setInfo('video', {'plot': "Crea backups ZIP de tus favoritos, categorías, historiales y configuración Trakt.\nRestaura desde un backup previo (modo Sustituir o Fusionar)."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="backup_menu"), listitem=li, isFolder=True)

    li = xbmcgui.ListItem(label=core_settings.apply_label("[B]Limpieza[/B]", bold=_bold, strip=_strip, color_mode=_color))
    li.setArt({'icon': _mi('adv_limpieza.png'), 'fanart': core_settings.addon_fanart()})
    li.setInfo('video', {'plot': "Opciones para liberar espacio: borrar cachés temporales, compactar la base de metadatos o restablecer el addon a estado de fábrica."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="cleanup_menu"), listitem=li, isFolder=True)

    li = xbmcgui.ListItem(label=core_settings.apply_label("[B]Atajos en ¿Dónde buscar?[/B]", bold=_bold, strip=_strip, color_mode=_color))
    li.setArt({'icon': _mi('adv_busqueda.png'), 'fanart': core_settings.addon_fanart()})
    li.setInfo('video', {'plot': (
        "Añade atajos al menú '¿Dónde buscar?' que aparece al hacer clic en cualquier película o serie.\n\n"
        "Puedes añadir cualquier addon instalado en Kodi para abrirlo directamente, o añadir "
        "comandos de Kodi.\n\n"
        "Los atajos aparecen en dorado dentro del menú.")})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="search_shortcuts_menu"), listitem=li, isFolder=True)

    li = xbmcgui.ListItem(label=core_settings.apply_label("[B]Ajustes del addon[/B]", bold=_bold, strip=_strip, color_mode=_color))
    li.setArt({'icon': _mi('adv_ajustes.png'), 'fanart': core_settings.addon_fanart()})
    li.setInfo('video', {'plot': "Abre el panel de ajustes del addon."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="open_addon_settings"), listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(h, cacheToDisc=False)


# Atajos en "¿Dónde buscar?"

def _topzilla_addon_id():
    try:
        return xbmcaddon.Addon().getAddonInfo('id')
    except Exception:
        return 'plugin.video.topzilla'


def _shortcut_addon_installed(sc):
    """Devuelve True si el atajo no depende de un addon o si el addon está instalado."""
    if not isinstance(sc, dict):
        return True
    aid = sc.get('addon_id')
    if not aid:
        # Atajos manuales sin addon_id asociado: no podemos validarlos, asumimos OK.
        return True
    try:
        return xbmc.getCondVisibility('System.HasAddon({0})'.format(aid))
    except Exception:
        return True


def _search_shortcuts_menu():
    h = int(sys.argv[1])
    _bold  = core_settings.get_acc_force_bold()
    _strip = core_settings.get_acc_strip_symbols()
    _color = core_settings.get_acc_color_mode()
    af = core_settings.addon_fanart()

    li = xbmcgui.ListItem(label=core_settings.apply_label(
        "[COLOR limegreen][B]+ Añadir atajo de addon instalado[/B][/COLOR]",
        bold=_bold, strip=_strip, color_mode=_color))
    li.setArt({'icon': _mi('shortcut_addon.png'), 'fanart': af})
    li.setInfo('video', {'plot': (
        "Selecciona cualquier addon instalado en Kodi para añadirlo como acceso directo "
        "en el menú '¿Dónde buscar?'. Al seleccionarlo desde ese menú se abrirá el addon "
        "directamente sin pasar por los menús de Kodi.")})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action='search_shortcut_add_addon'),
                                 listitem=li, isFolder=False)

    li = xbmcgui.ListItem(label=core_settings.apply_label(
        "[COLOR limegreen][B]+ Añadir comando[/B][/COLOR]",
        bold=_bold, strip=_strip, color_mode=_color))
    li.setArt({'icon': _mi('comando.png'), 'fanart': af})
    li.setInfo('video', {'plot': (
        "Escribe manualmente un nombre y un comando Kodi para añadirlo al menú '¿Dónde buscar?'. Ejemplos:\n"
        "  ActivateWindow(Videos,plugin://plugin.video.youtube/search/?q={query})\n"
        "  RunPlugin(plugin://plugin.video.dailymotion_com/?mode=search&keyword={query})\n"
        "  RunScript(script.foo,query={queryraw})\n"
        "  RunAddon(\"plugin.video.youtube\")\n\n"
        "Tokens disponibles:\n"
        "  {query}    - consulta URL-encoded (úsala dentro de URLs y plugin://...).\n"
        "  {queryraw} - consulta tal cual (úsala en RunScript, Notification, etc.).")})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action='search_shortcut_add_manual'),
                                 listitem=li, isFolder=False)

    li = xbmcgui.ListItem(label=core_settings.apply_label(
        "[COLOR limegreen][B]+ Añadir desde favoritos de Kodi[/B][/COLOR]",
        bold=_bold, strip=_strip, color_mode=_color))
    li.setArt({'icon': 'DefaultFavourites.png', 'fanart': af})
    li.setInfo('video', {'plot': (
        "Elige uno de los favoritos que ya tienes guardados en Kodi "
        "para añadirlo como atajo en el menú '¿Dónde buscar?'. "
        "Se conservan el nombre, el icono y el comando exactos.")})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action='search_shortcut_add_favourite'),
                                 listitem=li, isFolder=False)

    li = xbmcgui.ListItem(label=core_settings.apply_label(
        "[COLOR deepskyblue][B]↕ Reordenar ventana '¿Dónde buscar?'[/B][/COLOR]",
        bold=_bold, strip=_strip, color_mode=_color))
    li.setArt({'icon': _mi('adv_busqueda.png'), 'fanart': af})
    li.setInfo('video', {'plot': (
        "Cambia el orden en que aparecen TODAS las entradas del menú "
        "'¿Dónde buscar?' (YouTube, Dailymotion, Wikipedia, TMDB, Ficha completa, "
        "atajos personalizados, etc.). Puedes intercalar atajos entre las entradas fijas.")})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action='search_menu_reorder'),
                                 listitem=li, isFolder=False)

    li = xbmcgui.ListItem(label=core_settings.apply_label(
        "[COLOR khaki][B]── EXTRA ──[/B][/COLOR]",
        bold=_bold, strip=_strip, color_mode=_color))
    li.setArt({'icon': 'DefaultAddonNone.png', 'fanart': af})
    li.setInfo('video', {'plot': "Entradas opcionales para el menú '¿Dónde buscar?'."})
    xbmcplugin.addDirectoryItem(handle=h, url='', listitem=li, isFolder=False)

    ost_on = core_settings.show_soundtrack_button_enabled()
    ost_state = "[COLOR lime](ON)[/COLOR]" if ost_on else "[COLOR gray](OFF)[/COLOR]"
    li = xbmcgui.ListItem(label=core_settings.apply_label(
        "[B]♪ Buscar Banda Sonora en YouTube[/B] {0}".format(ost_state),
        bold=_bold, strip=_strip, color_mode=_color))
    li.setArt({'icon': 'DefaultMusicSongs.png', 'fanart': af})
    li.setInfo('video', {'plot': (
        "Al activarlo añade una entrada en el menú '¿Dónde buscar?' que lanza una búsqueda "
        "automática en YouTube de la banda sonora ('{título} {año} soundtrack').\n\n"
        "Requiere el addon plugin.video.youtube instalado.")})
    xbmcplugin.addDirectoryItem(
        handle=h,
        url=_u(action='toggle_soundtrack_button'),
        listitem=li, isFolder=False)

    omdb_on = core_settings.show_omdb_button_enabled()
    omdb_state = "[COLOR lime](ON)[/COLOR]" if omdb_on else "[COLOR gray](OFF)[/COLOR]"
    li = xbmcgui.ListItem(label=core_settings.apply_label(
        "[B]Críticas (RT / Metacritic / IMDb) vía OMDb[/B] {0}".format(omdb_state),
        bold=_bold, strip=_strip, color_mode=_color))
    li.setArt({'icon': 'DefaultIconInfo.png', 'fanart': af})
    li.setInfo('video', {'plot': (
        "Al activarlo añade una entrada en el menú '¿Dónde buscar?' que muestra "
        "las notas agregadas de Rotten Tomatoes, Metacritic e IMDb para la película "
        "seleccionada.\n\n"
        "Para mayor estabilidad, configura tu clave en Opciones → Claves API → OMDb.")})
    xbmcplugin.addDirectoryItem(
        handle=h,
        url=_u(action='toggle_omdb_button'),
        listitem=li, isFolder=False)

    share_on = core_settings.show_share_button_enabled()
    share_state = "[COLOR lime](ON)[/COLOR]" if share_on else "[COLOR gray](OFF)[/COLOR]"
    li = xbmcgui.ListItem(label=core_settings.apply_label(
        "[B]Compartir esta peli[/B] {0}".format(share_state),
        bold=_bold, strip=_strip, color_mode=_color))
    li.setArt({'icon': _mi('compartir.png'), 'fanart': af})
    li.setInfo('video', {'plot': (
        "Al activarlo añade una entrada en el menú '¿Dónde buscar?' que copia al portapapeles "
        "el título, año, nota TMDB y enlace de la película.\n\n"
        "Si la nota o el ID TMDB no estuvieran cacheados, se consulta TMDB en el momento "
        "(requiere clave en Opciones → Claves API).")})
    xbmcplugin.addDirectoryItem(
        handle=h,
        url=_u(action='toggle_share_button'),
        listitem=li, isFolder=False)

    li = xbmcgui.ListItem(label=core_settings.apply_label(
        "[COLOR khaki][B]── ATAJOS ──[/B][/COLOR]",
        bold=_bold, strip=_strip, color_mode=_color))
    li.setArt({'icon': 'DefaultAddonNone.png', 'fanart': af})
    li.setInfo('video', {'plot': "Atajos configurados para el menú '¿Dónde buscar?'."})
    xbmcplugin.addDirectoryItem(handle=h, url='', listitem=li, isFolder=False)

    shortcuts = core_settings.load_search_shortcuts()
    if not shortcuts:
        li = xbmcgui.ListItem(label=core_settings.apply_label(
            "[COLOR gray](Sin atajos configurados)[/COLOR]",
            bold=_bold, strip=_strip, color_mode=_color))
        li.setArt({'icon': 'DefaultIconInfo.png', 'fanart': af})
        xbmcplugin.addDirectoryItem(handle=h, url='', listitem=li, isFolder=False)
    else:
        for i, sc in enumerate(shortcuts):
            name = sc.get('name', 'Atajo {0}'.format(i + 1))
            icon = sc.get('icon') or 'DefaultAddonVideo.png'
            cmd  = sc.get('command', '')
            installed = _shortcut_addon_installed(sc)
            if installed:
                label = "[COLOR gold][B]{0}[/B][/COLOR]".format(name)
                plot  = "Comando: {0}".format(cmd)
            else:
                label = "[COLOR red][B]{0}[/B][/COLOR] [COLOR gray](addon no instalado)[/COLOR]".format(name)
                plot  = "[COLOR red]El addon '{0}' no está instalado.[/COLOR]\n\nComando: {1}".format(
                    sc.get('addon_id', ''), cmd)
            li = xbmcgui.ListItem(label=core_settings.apply_label(
                label, bold=_bold, strip=_strip, color_mode=_color))
            li.setArt({'icon': icon, 'fanart': af})
            li.setInfo('video', {'plot': plot})
            ctx = []
            ctx.append(("Renombrar",
                "RunPlugin({0})".format(_u(action='search_shortcut_rename', idx=i))))
            ctx.append(("Eliminar atajo",
                "RunPlugin({0})".format(_u(action='search_shortcut_remove', idx=i))))
            li.addContextMenuItems(ctx)
            xbmcplugin.addDirectoryItem(
                handle=h,
                url=_u(action='search_shortcut_actions', idx=i),
                listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(h, cacheToDisc=False)


def _search_shortcut_add_addon():
    addons = []
    for addon_type in ('xbmc.addon.video', 'xbmc.addon.audio',
                        'xbmc.addon.image', 'xbmc.addon.executable'):
        try:
            req = json.dumps({
                'jsonrpc': '2.0', 'method': 'Addons.GetAddons',
                'params': {'type': addon_type, 'enabled': True,
                           'properties': ['name', 'thumbnail']},
                'id': 1,
            })
            data = json.loads(xbmc.executeJSONRPC(req) or '{}')
            addons += (data.get('result') or {}).get('addons') or []
        except Exception:
            pass

    own_id = _topzilla_addon_id()
    seen = set()
    unique = []
    for a in addons:
        if not isinstance(a, dict):
            continue
        aid = a.get('addonid')
        if not aid or aid == own_id or aid in seen:
            continue
        seen.add(aid)
        unique.append(a)
    unique.sort(key=lambda x: (x.get('name') or '').lower())

    if not unique:
        xbmcgui.Dialog().notification('TopZilla', 'No se encontraron addons instalados',
                                       xbmcgui.NOTIFICATION_INFO, 3000)
        return

    names = [a.get('name') or a.get('addonid', '') for a in unique]
    sel = xbmcgui.Dialog().select('Seleccionar addon para añadir como atajo', names)
    if sel < 0:
        return

    addon    = unique[sel]
    addon_id = addon.get('addonid', '')
    name     = core_settings.sanitize_shortcut_name(addon.get('name')) or addon_id
    thumb    = addon.get('thumbnail') if isinstance(addon.get('thumbnail'), str) else ''
    if not thumb:
        thumb = 'DefaultAddonVideo.png'
    command  = 'RunAddon("{0}")'.format(addon_id)

    shortcuts = core_settings.load_search_shortcuts()
    for sc in shortcuts:
        if sc.get('addon_id') == addon_id or sc.get('command') == command:
            xbmcgui.Dialog().notification('TopZilla', 'Este addon ya está en los atajos',
                                           xbmcgui.NOTIFICATION_INFO, 2000)
            return

    shortcuts.append({'name': name, 'icon': thumb, 'command': command,
                      'type': 'addon', 'addon_id': addon_id})
    core_settings.save_search_shortcuts(shortcuts)
    xbmcgui.Dialog().notification('TopZilla', 'Atajo añadido: {0}'.format(name),
                                   xbmcgui.NOTIFICATION_INFO, 2000)
    xbmc.executebuiltin('Container.Refresh')


# Match RunAddon("addon.id") / RunAddon(addon.id) / plugin://addon.id/...
_RUNADDON_RE = re.compile(r'RunAddon\s*\(\s*"?([\w\.\-]+)"?\s*\)', re.IGNORECASE)
_PLUGIN_URL_RE = re.compile(r'plugin://([\w\.\-]+)', re.IGNORECASE)


def _extract_addon_id_from_command(cmd):
    if not cmd:
        return ''
    m = _RUNADDON_RE.search(cmd)
    if m:
        return m.group(1)
    m = _PLUGIN_URL_RE.search(cmd)
    if m:
        return m.group(1)
    return ''


def _search_shortcut_add_manual():
    kb = xbmc.Keyboard('', 'Nombre del atajo')
    kb.doModal()
    if not kb.isConfirmed():
        return
    name = core_settings.sanitize_shortcut_name(kb.getText())
    if not name:
        return

    kb2 = xbmc.Keyboard('', 'Comando (ActivateWindow, RunPlugin, RunScript, RunAddon...)')
    kb2.doModal()
    if not kb2.isConfirmed():
        return
    command = kb2.getText().strip()
    if not command:
        return

    shortcuts = core_settings.load_search_shortcuts()
    for sc in shortcuts:
        if sc.get('command') == command:
            xbmcgui.Dialog().notification('TopZilla', 'Ya existe un atajo con ese comando',
                                           xbmcgui.NOTIFICATION_INFO, 2000)
            return

    addon_id = _extract_addon_id_from_command(command)
    shortcuts.append({'name': name, 'icon': 'DefaultIconInfo.png', 'command': command,
                      'type': 'manual', 'addon_id': addon_id})
    core_settings.save_search_shortcuts(shortcuts)
    xbmcgui.Dialog().notification('TopZilla', 'Atajo añadido: {0}'.format(name),
                                   xbmcgui.NOTIFICATION_INFO, 2000)
    xbmc.executebuiltin('Container.Refresh')


def _search_shortcut_add_favourite():
    fav_path = xbmcvfs.translatePath('special://profile/favourites.xml')

    if not os.path.isfile(fav_path):
        xbmcgui.Dialog().notification('TopZilla', 'No tienes favoritos guardados en Kodi',
                                       xbmcgui.NOTIFICATION_INFO, 2500)
        return

    try:
        root = ET.parse(fav_path).getroot()
    except ET.ParseError:
        xbmcgui.Dialog().notification('TopZilla', 'Los favoritos de Kodi están dañados',
                                       xbmcgui.NOTIFICATION_ERROR, 2500)
        return
    except OSError:
        xbmcgui.Dialog().notification('TopZilla', 'No se pudieron leer los favoritos',
                                       xbmcgui.NOTIFICATION_ERROR, 2500)
        return

    favs = []
    for fav in root.findall('favourite'):
        cmd = (fav.text or '').strip()
        if not cmd:
            continue
        favs.append({
            'name':  core_settings.sanitize_shortcut_name(fav.get('name')) or cmd[:40],
            'thumb': fav.get('thumb') or '',
            'cmd':   cmd,
        })

    if not favs:
        xbmcgui.Dialog().notification('TopZilla', 'No hay favoritos en Kodi',
                                       xbmcgui.NOTIFICATION_INFO, 2500)
        return

    items = []
    for f in favs:
        it = xbmcgui.ListItem(label=f['name'])
        if f['thumb']:
            it.setArt({'icon': f['thumb'], 'thumb': f['thumb']})
        items.append(it)
    sel = xbmcgui.Dialog().select('Seleccionar favorito', items, useDetails=True)
    if sel < 0:
        return

    chosen  = favs[sel]
    command = chosen['cmd']

    shortcuts = core_settings.load_search_shortcuts()
    for sc in shortcuts:
        if sc.get('command') == command:
            xbmcgui.Dialog().notification('TopZilla', 'Ya existe un atajo con ese comando',
                                           xbmcgui.NOTIFICATION_INFO, 2000)
            return

    addon_id = _extract_addon_id_from_command(command)
    icon = chosen['thumb'] or 'DefaultFavourites.png'
    shortcuts.append({'name': chosen['name'], 'icon': icon, 'command': command,
                      'type': 'manual', 'addon_id': addon_id})
    core_settings.save_search_shortcuts(shortcuts)
    xbmcgui.Dialog().notification('TopZilla', 'Atajo añadido: {0}'.format(chosen['name']),
                                   xbmcgui.NOTIFICATION_INFO, 2000)
    xbmc.executebuiltin('Container.Refresh')


_ESPADAILY_INTRO_TEXT = (
    "Esta opción aparece porque tienes EspaDaily instalado.\n\n"
    "TopZilla salió de EspaDaily y, aunque siguen compartiendo origen, cada uno "
    "avanza por su lado. Muchas funciones hacen lo mismo pero por dentro están "
    "resueltas de forma distinta a propósito. De este modo, si una falla en un "
    "caso concreto, la otra puede que sí funcione. Con esta opción puedes saltar "
    "de uno al otro en un clic y quedarte con el que más te convenga en cada "
    "momento."
)


def _toggle_espadaily_integration():
    new_state = not core_settings._espadaily_integration_enabled()
    core_settings.set_espadaily_integration_enabled(new_state)
    if new_state:
        try:
            shown = xbmcaddon.Addon().getSetting('espadaily_intro_shown') == 'true'
        except Exception:
            shown = False
        if not shown:
            xbmcgui.Dialog().textviewer("Buscar en EspaDaily", _ESPADAILY_INTRO_TEXT)
            try:
                xbmcaddon.Addon().setSetting('espadaily_intro_shown', 'true')
            except Exception:
                pass
    msg = 'Integración EspaDaily activada' if new_state else 'Integración EspaDaily desactivada'
    xbmcgui.Dialog().notification('TopZilla', msg, xbmcgui.NOTIFICATION_INFO, 2000)
    xbmc.executebuiltin('Container.Refresh')


def _search_shortcut_remove(idx):
    shortcuts = core_settings.load_search_shortcuts()
    if 0 <= idx < len(shortcuts):
        name = shortcuts[idx].get('name', '')
        del shortcuts[idx]
        core_settings.save_search_shortcuts(shortcuts)
        xbmcgui.Dialog().notification('TopZilla', 'Atajo eliminado: {0}'.format(name),
                                       xbmcgui.NOTIFICATION_INFO, 2000)
    xbmc.executebuiltin('Container.Refresh')


def _search_shortcut_rename(idx):
    shortcuts = core_settings.load_search_shortcuts()
    if not (0 <= idx < len(shortcuts)):
        return
    kb = xbmc.Keyboard(shortcuts[idx].get('name', ''), 'Nuevo nombre')
    kb.doModal()
    if not kb.isConfirmed():
        return
    new_name = core_settings.sanitize_shortcut_name(kb.getText())
    if not new_name:
        return
    shortcuts[idx]['name'] = new_name
    core_settings.save_search_shortcuts(shortcuts)
    xbmc.executebuiltin('Container.Refresh')


def _search_shortcut_actions(idx):
    """Diálogo con las acciones disponibles para un atajo.
    Se invoca al hacer clic izquierdo sobre un atajo (alternativa accesible
    al menú contextual)."""
    shortcuts = core_settings.load_search_shortcuts()
    if not (0 <= idx < len(shortcuts)):
        return
    sc   = shortcuts[idx]
    name = sc.get('name', 'Atajo')

    options = ['Renombrar', '[COLOR red]Eliminar atajo[/COLOR]']
    actions = ['rename', 'remove']

    sel = xbmcgui.Dialog().select("'{0}' — ¿Qué acción?".format(name), options)
    if sel < 0:
        return

    action = actions[sel]
    if action == 'rename':
        _search_shortcut_rename(idx)
    elif action == 'remove':
        _search_shortcut_remove(idx)


def _search_menu_reorder():
    """Diálogo subir/bajar para reordenar la ventana '¿Dónde buscar?'.
    Muestra TODAS las entradas posibles (fijas + atajos) sin filtrar por
    modo, para que el orden valga tanto para películas como para series."""
    # Unimos las entradas posibles en modo 'movie' y 'show' por si en el
    # futuro alguno tiene exclusivas. Hoy son el mismo set.
    base = _build_search_entries('movie')
    ids_seen = {e[0] for e in base}
    for e in _build_search_entries('show'):
        if e[0] not in ids_seen:
            base.append(e)
            ids_seen.add(e[0])
    base = [e for e in base if e[0]]  # descartar entradas sin id

    saved = core_settings.load_search_menu_order()
    if saved:
        index = {eid: i for i, eid in enumerate(saved)}
        base.sort(key=lambda e: index.get(e[0], 10**6))

    while True:
        labels = []
        for i, (_eid, lbl, _act, _vis) in enumerate(base):
            arrows = ''
            if i > 0:
                arrows += '↑ '
            if i < len(base) - 1:
                arrows += '↓ '
            labels.append("{0}{1}".format(arrows, lbl))
        reset_pos = len(labels)
        labels.append("[COLOR orange]Restaurar orden por defecto[/COLOR]")

        sel = xbmcgui.Dialog().select("Reordenar '¿Dónde buscar?' (los cambios se guardan al instante)", labels)
        if sel < 0:
            return
        if sel == reset_pos:
            if xbmcgui.Dialog().yesno("TopZilla",
                    "¿Restaurar el orden por defecto del menú '¿Dónde buscar?'?"):
                core_settings.reset_search_menu_order()
                xbmcgui.Dialog().notification('TopZilla',
                    'Orden restaurado', xbmcgui.NOTIFICATION_INFO, 1500)
                return
            continue

        # Submenú subir/bajar para el elemento seleccionado.
        opts = []
        if sel > 0:
            opts.append(('up',   '↑ Subir'))
        if sel < len(base) - 1:
            opts.append(('down', '↓ Bajar'))
        opts.append(('cancel', 'Cancelar'))
        choice = xbmcgui.Dialog().select("Mover elemento", [o[1] for o in opts])
        if choice < 0 or opts[choice][0] == 'cancel':
            continue
        if opts[choice][0] == 'up':
            base[sel - 1], base[sel] = base[sel], base[sel - 1]
        else:
            base[sel], base[sel + 1] = base[sel + 1], base[sel]
        core_settings.save_search_menu_order([e[0] for e in base])


def _trakt_lists_reorder():
    """Diálogo subir/bajar para reordenar las listas Trakt del menú raíz."""
    lists = list(core_settings.get_trakt_lists())
    order = core_settings.load_trakt_lists_order()
    if order:
        index = {lid: i for i, lid in enumerate(order)}
        lists.sort(key=lambda l: index.get(l.get("id", ""), 10**6))

    if not lists:
        xbmcgui.Dialog().ok("TopZilla", "No hay listas Trakt para reordenar.")
        return

    while True:
        labels = []
        for i, l in enumerate(lists):
            arrows = ''
            if i > 0:
                arrows += '↑ '
            if i < len(lists) - 1:
                arrows += '↓ '
            count = l.get('item_count', 0)
            labels.append("{0}[B]{1}[/B] [COLOR gray]({2} ítems)[/COLOR]".format(
                arrows, l.get('name', l.get('id', '')), count))
        reset_pos = len(labels)
        labels.append("[COLOR orange]Restaurar orden por defecto[/COLOR]")

        sel = xbmcgui.Dialog().select(
            "Reordenar listas Trakt (los cambios se guardan al instante)", labels)
        if sel < 0:
            return
        if sel == reset_pos:
            if xbmcgui.Dialog().yesno("TopZilla",
                    "¿Restaurar el orden por defecto de las listas Trakt?"):
                core_settings.reset_trakt_lists_order()
                xbmcgui.Dialog().notification('TopZilla',
                    'Orden restaurado', xbmcgui.NOTIFICATION_INFO, 1500)
                return
            continue

        opts = []
        if sel > 0:
            opts.append(('up',   '↑ Subir'))
        if sel < len(lists) - 1:
            opts.append(('down', '↓ Bajar'))
        opts.append(('cancel', 'Cancelar'))
        choice = xbmcgui.Dialog().select("Mover elemento", [o[1] for o in opts])
        if choice < 0 or opts[choice][0] == 'cancel':
            continue
        if opts[choice][0] == 'up':
            lists[sel - 1], lists[sel] = lists[sel], lists[sel - 1]
        else:
            lists[sel], lists[sel + 1] = lists[sel + 1], lists[sel]
        core_settings.save_trakt_lists_order([l.get('id', '') for l in lists])


def _api_keys_menu():
    h = int(sys.argv[1])
    _bold  = core_settings.get_acc_force_bold()
    _strip = core_settings.get_acc_strip_symbols()
    _color = core_settings.get_acc_color_mode()
    fanart = core_settings.addon_fanart()

    tmdb_user = core_settings.get_tmdb_user_key()
    tmdb_tag  = "[COLOR green]Personalizada[/COLOR]" if tmdb_user else "[COLOR grey]No configurada[/COLOR]"
    li = xbmcgui.ListItem(label=core_settings.apply_label(
        "[B]TMDB:[/B] {0}".format(tmdb_tag), bold=_bold, strip=_strip, color_mode=_color))
    li.setArt({'icon': _mi('adv_api_key.png'), 'fanart': fanart})
    li.setInfo('video', {'plot': (
        "Clave API para metadatos, carátulas y calendarios de TMDB.\n\n"
        "Usar esta clave mejora la estabilidad del addon. Si el addon empieza a fallar, cámbiala.\n\n"
        "[COLOR blue][I]Pulsa para introducir o borrar tu clave.[/I][/COLOR]"
    )})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="api_key_set_tmdb"), listitem=li, isFolder=False)

    trakt_user = core_settings.get_trakt_user_key()
    trakt_tag  = "[COLOR green]Personalizada[/COLOR]" if trakt_user else "[COLOR grey]No configurada[/COLOR]"
    li = xbmcgui.ListItem(label=core_settings.apply_label(
        "[B]Trakt Client ID:[/B] {0}".format(trakt_tag), bold=_bold, strip=_strip, color_mode=_color))
    li.setArt({'icon': _mi('adv_api_key.png'), 'fanart': fanart})
    li.setInfo('video', {'plot': (
        "Client ID para las listas y funciones de Trakt.tv.\n\n"
        "Usar este Client ID mejora la estabilidad del addon. Si el addon empieza a fallar, cámbialo.\n\n"
        "[COLOR blue][I]Pulsa para introducir o borrar tu clave.[/I][/COLOR]"
    )})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="api_key_set_trakt"), listitem=li, isFolder=False)

    omdb_user = core_settings.get_omdb_user_key()
    omdb_tag  = "[COLOR green]Personalizada[/COLOR]" if omdb_user else "[COLOR grey]No configurada[/COLOR]"
    li = xbmcgui.ListItem(label=core_settings.apply_label(
        "[B]OMDb:[/B] {0}".format(omdb_tag), bold=_bold, strip=_strip, color_mode=_color))
    li.setArt({'icon': _mi('adv_api_key.png'), 'fanart': fanart})
    li.setInfo('video', {'plot': (
        "Clave API para consultar puntuaciones de Rotten Tomatoes, "
        "Metacritic e IMDb (botón 'Críticas' en el menú ¿Dónde buscar?).\n\n"
        "Usar esta clave mejora la estabilidad del addon. Si el addon empieza a fallar, cámbiala.\n\n"
        "Puedes obtener una en omdbapi.com/apikey.aspx\n\n"
        "[COLOR blue][I]Pulsa para introducir o borrar tu clave.[/I][/COLOR]"
    )})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="api_key_set_omdb"), listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(h, cacheToDisc=False)


def _api_key_prompt(current, prompt, validator):
    """Pide una clave por teclado y la valida.
    Devuelve la nueva clave (str) si el usuario confirma, o None si cancela."""
    kb = xbmc.Keyboard(current, prompt)
    kb.doModal()
    if not kb.isConfirmed():
        return None
    new_key = kb.getText().strip()
    if not new_key:
        return new_key  # vacío = limpiar, sin validación
    bg = xbmcgui.DialogProgressBG()
    bg.create("TopZilla", "Validando clave...")
    try:
        valid = validator(new_key)
    finally:
        bg.close()
    if valid is False:
        if not xbmcgui.Dialog().yesno(
            "TopZilla — Clave inválida",
            "La API rechaza esta clave (no autorizada).\n\n¿Guardarla igualmente?",
            nolabel="Cancelar", yeslabel="Guardar"
        ):
            return None
    return new_key


def _api_key_set_tmdb():
    current = core_settings.get_tmdb_user_key()
    new_key = _api_key_prompt(current,
                               'Clave API de TMDB (dejar vacio para usar la integrada)',
                               core_settings.validate_tmdb_key)
    if new_key is None:
        return
    if not core_settings.set_tmdb_api_key(new_key):
        xbmcgui.Dialog().notification("TopZilla", "No se pudo guardar la clave",
                                       xbmcgui.NOTIFICATION_ERROR, 3000)
        return
    if new_key != current and xbmcgui.Dialog().yesno(
        "TopZilla",
        "Clave guardada. ¿Borrar la caché de metadatos para que se redescargue con la nueva clave?",
        nolabel="No", yeslabel="Borrar caché"
    ):
        try:
            import metadata_enricher
            metadata_enricher.delete_db()
        except Exception:
            xbmcgui.Dialog().notification("TopZilla", "No se pudo borrar la cache",
                                           xbmcgui.NOTIFICATION_WARNING, 3000)
    xbmcgui.Dialog().notification("TopZilla", "Clave TMDB guardada",
                                   xbmcgui.NOTIFICATION_INFO, 2500)
    xbmc.executebuiltin("Container.Refresh")


def _api_key_set_trakt():
    current = core_settings.get_trakt_user_key()
    new_key = _api_key_prompt(current,
                               'Client ID de Trakt (dejar vacio para usar el integrado)',
                               core_settings.validate_trakt_key)
    if new_key is None:
        return
    if not core_settings.set_trakt_api_key(new_key):
        xbmcgui.Dialog().notification("TopZilla", "No se pudo guardar la clave",
                                       xbmcgui.NOTIFICATION_ERROR, 3000)
        return
    xbmcgui.Dialog().notification("TopZilla", "Clave Trakt guardada",
                                   xbmcgui.NOTIFICATION_INFO, 2500)
    xbmc.executebuiltin("Container.Refresh")


def _api_key_set_omdb():
    import omdb
    current = core_settings.get_omdb_user_key()
    new_key = _api_key_prompt(current,
                               'Clave API de OMDb',
                               omdb.validate_key)
    if new_key is None:
        return
    if not core_settings.set_omdb_api_key(new_key):
        xbmcgui.Dialog().notification("TopZilla", "No se pudo guardar la clave",
                                       xbmcgui.NOTIFICATION_ERROR, 3000)
        return
    xbmcgui.Dialog().notification("TopZilla", "Clave OMDb guardada",
                                   xbmcgui.NOTIFICATION_INFO, 2500)
    xbmc.executebuiltin("Container.Refresh")


# Fanart de fondo

_FANART_MODES   = ['addon', 'custom', 'disabled']
_FANART_MODE_TAGS = {
    'addon':    '[COLOR green]Imagen del addon[/COLOR]',
    'custom':   '[COLOR cyan]Imagen personalizada[/COLOR]',
    'disabled': '[COLOR red]Desactivado[/COLOR]',
}
_FANART_MODE_PLOTS = {
    'addon':    "Se usa la imagen fanart.png incluida con el addon.",
    'custom':   "Se usa la imagen que hayas seleccionado tú.",
    'disabled': "No se muestra ninguna imagen de fondo en los menús.",
}


def _fanart_menu():
    h = int(sys.argv[1])
    _bold  = core_settings.get_acc_force_bold()
    _strip = core_settings.get_acc_strip_symbols()
    _color = core_settings.get_acc_color_mode()
    _fanart = core_settings.addon_fanart()

    mode = core_settings.get_fanart_mode()
    mode_tag = _FANART_MODE_TAGS.get(mode, mode)
    mode_plot = _FANART_MODE_PLOTS.get(mode, '')
    li = xbmcgui.ListItem(label=core_settings.apply_label(
        "[B]Modo[/B]  {0}".format(mode_tag), bold=_bold, strip=_strip, color_mode=_color))
    li.setArt({'icon': _mi('adv_refrescar.png'), 'fanart': _fanart})
    li.setInfo('video', {'plot': "{0}\n\nPulsa para cambiar entre imagen del addon, imagen personalizada y desactivado.".format(mode_plot)})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="fanart_cycle_mode"), listitem=li, isFolder=False)

    custom_path = core_settings.get_custom_fanart_path()
    if custom_path:
        custom_tag = "[COLOR cyan]{0}[/COLOR]".format(custom_path)
        custom_plot = "Imagen actual: {0}\n\nPulsa para elegir otra imagen.".format(custom_path)
    else:
        custom_tag = "[COLOR grey]Sin configurar[/COLOR]"
        custom_plot = "Aún no has seleccionado ninguna imagen personalizada.\n\nPulsa para explorar tus archivos y elegir una."
    li = xbmcgui.ListItem(label=core_settings.apply_label(
        "[B]Imagen personalizada[/B]  {0}".format(custom_tag), bold=_bold, strip=_strip, color_mode=_color))
    li.setArt({'icon': 'DefaultFolder.png', 'fanart': _fanart})
    li.setInfo('video', {'plot': custom_plot + "\n\nFormatos soportados: JPG, PNG."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="fanart_browse_custom"), listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(h, cacheToDisc=False)


def _fanart_cycle_mode():
    mode = core_settings.get_fanart_mode()
    modes = _FANART_MODES
    next_mode = modes[(modes.index(mode) + 1) % len(modes)] if mode in modes else 'addon'
    core_settings.set_fanart_mode(next_mode)
    xbmc.executebuiltin("Container.Refresh")


def _fanart_browse_custom():
    path = str(xbmcgui.Dialog().browse(1, 'Seleccionar imagen de fondo', 'files', '.jpg|.jpeg|.png', False, False, ''))
    if path and path != '0' and os.path.exists(path):
        core_settings.set_custom_fanart_path(path)
        core_settings.set_fanart_mode('custom')
    xbmc.executebuiltin("Container.Refresh")


def _accessibility_menu():
    h = int(sys.argv[1])

    color_mode = core_settings.get_acc_color_mode()
    bold_on    = core_settings.get_acc_force_bold()
    strip_sym  = core_settings.get_acc_strip_symbols()

    _bold  = bold_on
    _strip = strip_sym
    _color = color_mode

    color_name = _ACC_COLOR_NAMES.get(color_mode, color_mode)
    color_tag  = "[COLOR green]" if color_mode != 'none' else "[COLOR grey]"
    li = xbmcgui.ListItem(label=core_settings.apply_label(
        "[B]Modo de color:[/B] {0}{1}[/COLOR]".format(color_tag, color_name),
        bold=_bold, strip=_strip, color_mode=_color))
    li.setArt({'icon': _mi('adv_accesibilidad.png'), 'fanart': core_settings.addon_fanart()})
    li.setInfo('video', {'plot': _ACC_COLOR_PLOTS.get(color_mode, "") + "\n\n[COLOR blue][I]Pulsa para cambiar el modo de color.[/I][/COLOR]"})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="acc_set_color"), listitem=li, isFolder=False)

    bold_tag = core_settings.state_tag(bold_on)
    li = xbmcgui.ListItem(label=core_settings.apply_label(
        "[B]Negrita forzada:[/B] {0}".format(bold_tag),
        bold=_bold, strip=_strip, color_mode=_color))
    li.setArt({'icon': _mi('adv_accesibilidad.png'), 'fanart': core_settings.addon_fanart()})
    li.setInfo('video', {'plot': "Muestra los títulos de películas y secciones en negrita.\n\n[COLOR blue][I]Pulsa para activar/desactivar.[/I][/COLOR]"})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="acc_toggle_bold"), listitem=li, isFolder=False)

    sym_tag = "[COLOR green]ACTIVADA[/COLOR]" if strip_sym else "[COLOR grey]DESACTIVADA[/COLOR]"
    li = xbmcgui.ListItem(label=core_settings.apply_label(
        "[B]Sustitución de símbolos especiales:[/B] {0}".format(sym_tag),
        bold=_bold, strip=_strip, color_mode=_color))
    li.setArt({'icon': _mi('adv_accesibilidad.png'), 'fanart': core_settings.addon_fanart()})
    li.setInfo('video', {'plot': "Reemplaza caracteres Unicode especiales (★ ● ▲ ▼ etc.) por equivalentes ASCII (* ^ v).\nÚtil si tu skin no muestra correctamente estos caracteres.\n\n[COLOR blue][I]Pulsa para activar/desactivar.[/I][/COLOR]"})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="acc_toggle_symbols"), listitem=li, isFolder=False)

    font_size_on = core_settings.get_acc_font_size()
    font_tag = core_settings.state_tag(font_size_on)
    li = xbmcgui.ListItem(label=core_settings.apply_label(
        "[B]Texto en mayúsculas:[/B] {0}".format(font_tag),
        bold=_bold, strip=_strip, color_mode=_color, font_size=font_size_on))
    li.setArt({'icon': _mi('adv_accesibilidad.png'), 'fanart': core_settings.addon_fanart()})
    li.setInfo('video', {'plot': "Muestra todo el texto del addon en MAYÚSCULAS para mejorar la legibilidad.\n\n[COLOR blue][I]Pulsa para activar/desactivar.[/I][/COLOR]"})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="acc_toggle_font_size"), listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(h, cacheToDisc=False)


def _acc_set_color():
    modes = list(_ACC_COLOR_NAMES.keys())
    current = core_settings.get_acc_color_mode()
    idx = modes.index(current) if current in modes else 0
    chosen = xbmcgui.Dialog().select("Modo de color", list(_ACC_COLOR_NAMES.values()), preselect=idx)
    if chosen < 0:
        xbmcplugin.endOfDirectory(int(sys.argv[1]), succeeded=False)
        return
    core_settings.set_acc_color_mode(modes[chosen])
    xbmcgui.Dialog().notification("TopZilla", "Modo de color guardado.", xbmcgui.NOTIFICATION_INFO, 3000)
    xbmcplugin.endOfDirectory(int(sys.argv[1]), succeeded=False)
    xbmc.executebuiltin("Container.Refresh")


def _acc_toggle_bold():
    new_val = not core_settings.get_acc_force_bold()
    core_settings.set_acc_force_bold(new_val)
    msg = "ACTIVADA" if new_val else "DESACTIVADA"
    xbmcgui.Dialog().notification("TopZilla", "Negrita {0}.".format(msg), xbmcgui.NOTIFICATION_INFO, 3000)
    xbmcplugin.endOfDirectory(int(sys.argv[1]), succeeded=False)
    xbmc.executebuiltin("Container.Refresh")


def _acc_toggle_symbols():
    new_val = not core_settings.get_acc_strip_symbols()
    core_settings.set_acc_strip_symbols(new_val)
    msg = "ACTIVADA" if new_val else "DESACTIVADA"
    xbmcgui.Dialog().notification("TopZilla", "Sustitución de símbolos {0}.".format(msg), xbmcgui.NOTIFICATION_INFO, 4000)
    xbmcplugin.endOfDirectory(int(sys.argv[1]), succeeded=False)
    xbmc.executebuiltin("Container.Refresh")


def _acc_toggle_font_size():
    new_val = not core_settings.get_acc_font_size()
    core_settings.set_acc_font_size(new_val)
    msg = "ACTIVADA" if new_val else "DESACTIVADA"
    xbmcgui.Dialog().notification("TopZilla", "Texto en mayúsculas {0}.".format(msg), xbmcgui.NOTIFICATION_INFO, 3000)
    xbmcplugin.endOfDirectory(int(sys.argv[1]), succeeded=False)
    xbmc.executebuiltin("Container.Refresh")


def _cleanup_menu():
    h = int(sys.argv[1])
    _bold  = core_settings.get_acc_force_bold()
    _strip = core_settings.get_acc_strip_symbols()
    _color = core_settings.get_acc_color_mode()

    li = xbmcgui.ListItem(label=core_settings.apply_label("[COLOR yellow][B]Limpiar caché (recomendado)[/B][/COLOR]", bold=_bold, strip=_strip, color_mode=_color))
    li.setArt({'icon': _mi('adv_cache.png'), 'fanart': core_settings.addon_fanart()})
    li.setInfo('video', {'plot': "Borra los archivos de caché temporales: miniaturas TMDB, metadatos de FilmAffinity, SensaCine, Cinemeta y carátulas de películas.\n\nNo afecta a tus ajustes ni a la configuración de accesibilidad."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="cleanup_caches"), listitem=li, isFolder=False)

    li = xbmcgui.ListItem(label=core_settings.apply_label("[COLOR cyan][B]Compactar base de metadatos[/B][/COLOR]", bold=_bold, strip=_strip, color_mode=_color))
    li.setArt({'icon': 'DefaultHardDisk.png', 'fanart': core_settings.addon_fanart()})
    li.setInfo('video', {'plot': "Elimina las entradas caducadas (más de 30 días) de la base de datos de metadatos TMDB y compacta el archivo.\n\nMantiene los datos recientes y libera el espacio que ocupaban los caducados."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="vacuum_metadata_db"), listitem=li, isFolder=False)

    li = xbmcgui.ListItem(label=core_settings.apply_label("[COLOR orange][B]Borrar base de metadatos completa[/B][/COLOR]", bold=_bold, strip=_strip, color_mode=_color))
    li.setArt({'icon': 'DefaultHardDisk.png', 'fanart': core_settings.addon_fanart()})
    li.setInfo('video', {'plot': "Elimina por completo la base de datos de metadatos TMDB.\n\nLos metadatos se volverán a descargar cuando navegues. No afecta a favoritos, categorías ni historiales."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="delete_metadata_db"), listitem=li, isFolder=False)

    li = xbmcgui.ListItem(label=core_settings.apply_label("[COLOR red][B]Restablecer addon (factory reset)[/B][/COLOR]", bold=_bold, strip=_strip, color_mode=_color))
    li.setArt({'icon': 'DefaultIconError.png', 'fanart': core_settings.addon_fanart()})
    li.setInfo('video', {'plot': "BORRA TODOS LOS DATOS DEL ADDON y deja la instalación como recién instalada.\n\nSe pierden tus favoritos, categorías, historiales, atajos de búsqueda, listas de Trakt, cachés, base de metadatos, backups y todos los ajustes (accesibilidad, claves API, descargas y menú contextual).\n\nEsta acción NO se puede deshacer."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="factory_reset"), listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(h, cacheToDisc=False)


def _cleanup_caches():
    if not xbmcgui.Dialog().yesno(
        "TopZilla - Limpieza",
        "¿Borrar los archivos de caché temporales?\n\nNo afecta a tus favoritos, categorías, historiales ni ajustes."
    ):
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
        return

    profile = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    freed = 0
    cache_files = [
        'topzilla_fa_cache.json',
        'topzilla_sc_cache.json',
        'topzilla_cinemeta_cache.json',
        'topzilla_tmdb_lists_cache.json',
        'topzilla_on_air_calendar.json',
        'topzilla_top_movies_thumbs.json',
        'topzilla_yt_search_cache.json',
        'topzilla_wikipedia_cache.json',
        'topzilla_explore_cache.json',
        'trakt_meta_items.json',
        'trakt_meta_downloaded.flag',
    ]
    for fn in cache_files:
        fp = os.path.join(profile, fn)
        if os.path.exists(fp):
            try:
                freed += os.path.getsize(fp)
                os.remove(fp)
            except OSError:
                pass

    # Carátulas Trakt (patrón trakt_thumbs_*.json) — todas son reconstruibles
    if os.path.exists(profile):
        for fn in os.listdir(profile):
            if fn.startswith('trakt_thumbs_') and fn.endswith('.json'):
                fp = os.path.join(profile, fn)
                try:
                    freed += os.path.getsize(fp)
                    os.remove(fp)
                except OSError:
                    pass

    xbmcgui.Dialog().ok(
        "TopZilla - Limpieza",
        "Caché borrada.\n\nSe han liberado {0}.".format(_human_size(freed))
    )
    xbmc.executebuiltin("Container.Refresh")
    xbmcplugin.endOfDirectory(int(sys.argv[1]))


def _vacuum_metadata_db():
    if not xbmcgui.Dialog().yesno(
        "TopZilla - Compactar metadatos",
        "¿Eliminar entradas caducadas (más de 30 días) y compactar la base de datos?\n\nLos metadatos recientes se conservan."
    ):
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
        return
    try:
        import metadata_enricher
        deleted, freed = metadata_enricher.prune_and_vacuum()
        xbmcgui.Dialog().ok(
            "TopZilla - Compactar metadatos",
            "Se han borrado {0} entradas y liberado {1}.".format(deleted, _human_size(freed))
        )
    except Exception as e:
        xbmcgui.Dialog().ok("TopZilla - Error", "No se pudo compactar.\n\n{0}".format(str(e)))
    xbmc.executebuiltin("Container.Refresh")
    xbmcplugin.endOfDirectory(int(sys.argv[1]))


def _delete_metadata_db():
    if not xbmcgui.Dialog().yesno(
        "TopZilla - Borrar metadatos",
        "¿Borrar completamente la base de datos de metadatos TMDB?\n\nLos metadatos se volverán a descargar al navegar. No afecta a favoritos, categorías ni historiales.",
        nolabel="Cancelar",
        yeslabel="Borrar"
    ):
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
        return
    try:
        import metadata_enricher
        freed = metadata_enricher.delete_db()
    except Exception as e:
        xbmcgui.Dialog().ok("TopZilla - Error", "No se pudo borrar la base de datos.\n\n{0}".format(str(e)))
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
        return
    xbmcgui.Dialog().ok(
        "TopZilla - Borrar metadatos",
        "Base de datos eliminada.\n\nSe han liberado {0}.".format(_human_size(freed))
    )
    xbmc.executebuiltin("Container.Refresh")
    xbmcplugin.endOfDirectory(int(sys.argv[1]))


def _factory_reset():
    if not xbmcgui.Dialog().yesno(
        "TopZilla - Restablecer addon",
        "Vas a BORRAR TODOS LOS DATOS DEL ADDON y dejarlo como recién instalado.\n\nSe perderán: tus favoritos, categorías, historiales (visionado, navegación, búsquedas), atajos de búsqueda, listas de Trakt importadas, los cachés, la base de metadatos, los backups guardados y todos los ajustes (accesibilidad, claves API, descargas automáticas y menú contextual).\n\nEsta acción NO se puede deshacer. ¿Continuar?",
        nolabel="Cancelar",
        yeslabel="Restablecer"
    ):
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
        return

    core_settings.reset_all_settings()

    profile = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    if os.path.exists(profile):
        for fn in os.listdir(profile):
            fp = os.path.join(profile, fn)
            if fn.endswith('.json') or fn.endswith('.db') or fn.endswith('.flag'):
                try:
                    os.remove(fp)
                except Exception:
                    pass
        backups_dir = os.path.join(profile, 'backups')
        if os.path.isdir(backups_dir):
            for fn in os.listdir(backups_dir):
                fp = os.path.join(backups_dir, fn)
                try:
                    os.remove(fp)
                except Exception:
                    pass

    xbmcgui.Dialog().notification("TopZilla", "Addon restablecido", xbmcgui.NOTIFICATION_INFO)
    xbmc.executebuiltin("Container.Refresh")
    xbmcplugin.endOfDirectory(int(sys.argv[1]))


# Alternativas de reproducción

def _build_search_entries(mode):
    """Devuelve [(id, label, action, visible)] con TODAS las entradas posibles
    del menú '¿Dónde buscar?' (fijas + atajos), en su orden por defecto."""
    has_yt   = xbmc.getCondVisibility("System.HasAddon(plugin.video.youtube)")
    has_emb  = False
    try:
        import context_menu as _cm
        has_emb = _cm.has_embuary()
    except Exception:
        pass
    espa_on  = (core_settings._espadaily_integration_enabled()
                and xbmc.getCondVisibility("System.HasAddon(plugin.video.espadaily)"))
    is_mov_show = mode in ('movie', 'show')
    ost_on   = core_settings.show_soundtrack_button_enabled()
    omdb_on  = core_settings.show_omdb_button_enabled()
    share_on = core_settings.show_share_button_enabled()

    emb_label = ("[COLOR orange]Ficha[/COLOR]" if has_emb
                 else "[COLOR gray]Ficha (instala Embuary Info)[/COLOR]")

    entries = [
        ('watch_providers',    "[COLOR lightgreen]¿Dónde verla en España?[/COLOR]",   'watch_providers',    is_mov_show),
        ('omdb_reviews',       "[COLOR orange]Críticas (RT / Metacritic / IMDb)[/COLOR]", 'omdb_reviews',  omdb_on and is_mov_show),
        ('youtube',            "[COLOR red]Buscar en YouTube[/COLOR]",                'youtube',            has_yt),
        ('soundtrack_yt',      "[COLOR magenta]Buscar Banda Sonora[/COLOR]",          'soundtrack_yt',      ost_on and has_yt and is_mov_show),
        ('dailymotion_native', "[COLOR cyan]Buscar en Dailymotion[/COLOR]",           'dailymotion_native', True),
        ('tmdb_extras',        "[COLOR white]Más información[/COLOR]",                'tmdb_extras',        is_mov_show),
        ('wikipedia',          "[COLOR deepskyblue]Buscar en Wikipedia[/COLOR]",      'wikipedia',          True),
        ('embuary_info',       emb_label,                                             'embuary_info',       is_mov_show),
        ('open_espadaily',     "[COLOR violet]Buscar en EspaDaily[/COLOR]",           'open_espadaily',     espa_on),
        ('share_movie',        "[COLOR pink]Compartir esta peli[/COLOR]",             'share_movie',        share_on and is_mov_show),
    ]

    for i, sc in enumerate(core_settings.load_search_shortcuts()):
        sid  = core_settings.shortcut_stable_id(sc)
        name = sc.get('name', 'Atajo {0}'.format(i + 1))
        if _shortcut_addon_installed(sc):
            lbl = "[COLOR gold]{0}[/COLOR]".format(name)
        else:
            lbl = "[COLOR red]{0} (no instalado)[/COLOR]".format(name)
        entries.append((sid, lbl, 'custom_{0}'.format(i), bool(sid)))

    return entries


def _copy_to_clipboard(text):
    if not text:
        return False
    data = text.encode('utf-8')
    try:
        import subprocess
        if xbmc.getCondVisibility('System.Platform.Windows'):
            try:
                CREATE_NO_WINDOW = 0x08000000
                p = subprocess.Popen(['clip'], stdin=subprocess.PIPE,
                                     creationflags=CREATE_NO_WINDOW)
                p.communicate(input=data)
                return p.returncode == 0
            except (OSError, IOError):
                return False
        if xbmc.getCondVisibility('System.Platform.OSX'):
            try:
                p = subprocess.Popen(['pbcopy'], stdin=subprocess.PIPE)
                p.communicate(input=data)
                return p.returncode == 0
            except (OSError, IOError):
                return False
        if xbmc.getCondVisibility('System.Platform.Linux'):
            import shutil
            for cmd in (['wl-copy'], ['xclip', '-selection', 'clipboard'], ['xsel', '-b', '-i']):
                if not shutil.which(cmd[0]):
                    continue
                try:
                    p = subprocess.Popen(cmd, stdin=subprocess.PIPE)
                    p.communicate(input=data)
                    if p.returncode == 0:
                        return True
                except (OSError, IOError):
                    continue
            return False
    except Exception:
        return False
    return False


def _search_alternatives_prompt(query, ot='', mode='', ref=None):
    h = int(sys.argv[1])

    entries = _build_search_entries(mode)
    order   = core_settings.load_search_menu_order()
    if order:
        index = {eid: i for i, eid in enumerate(order)}
        # Las entradas no presentes en el orden guardado van al final.
        entries.sort(key=lambda e: index.get(e[0], 10**6))
    entries = [e for e in entries if e[3]]

    opciones = [e[1] for e in entries]
    acciones = [e[2] for e in entries]

    if not any(a.startswith('custom_') for a in acciones):
        opciones.append("[COLOR gray]Puedes añadir más en Opciones[/COLOR]")
        acciones.append("hint_shortcuts")

    if not opciones:
        xbmcgui.Dialog().ok(
            "TopZilla",
            "No hay addons de reproducción instalados.\n\nInstala YouTube para buscar '{0}'.".format(query),
        )
        xbmcplugin.endOfDirectory(h, cacheToDisc=False)
        return

    idx = xbmcgui.Dialog().select("¿Dónde buscar '{0}'?".format(query), opciones)
    if idx < 0:
        xbmcplugin.endOfDirectory(h, cacheToDisc=False)
        return

    accion = acciones[idx]

    if accion == "watch_providers":
        import metadata_enricher as me
        me_mode = mode if mode in ('movie', 'show') else 'movie'
        meta = me.enrich(title=query, media_type=me_mode)
        tmdb_id = str((meta.get('ids') or {}).get('tmdb', '')) if meta else ''
        if not tmdb_id:
            xbmcgui.Dialog().notification("TopZilla", "No se pudo identificar en TMDB", xbmcgui.NOTIFICATION_WARNING)
            xbmcplugin.endOfDirectory(h, cacheToDisc=False)
            return
        providers = me.fetch_watch_providers(tmdb_id, media_type=me_mode)
        lines = []
        if providers.get('flatrate'):
            lines.append("Suscripción: " + ", ".join(providers['flatrate']))
        if providers.get('free'):
            lines.append("Gratis: " + ", ".join(providers['free']))
        if providers.get('rent'):
            lines.append("Alquiler: " + ", ".join(providers['rent']))
        if providers.get('buy'):
            lines.append("Compra: " + ", ".join(providers['buy']))
        if lines:
            xbmcgui.Dialog().textviewer(
                "¿Dónde ver '{0}' en España?".format(query),
                "\n".join(lines),
            )
        else:
            xbmcgui.Dialog().ok(
                "¿Dónde ver '{0}'?".format(query),
                "No disponible en ninguna plataforma de streaming en España según TMDB.",
            )
        xbmcplugin.endOfDirectory(h, cacheToDisc=False)

    elif accion == "omdb_reviews":
        api_key = core_settings.get_omdb_api_key()
        if not api_key:
            xbmcplugin.endOfDirectory(h, succeeded=False, cacheToDisc=False)
            if xbmcgui.Dialog().yesno(
                "OMDb",
                "Configura tu clave de OMDb en Opciones → Claves API.\n\n"
                "Puedes obtener una en omdbapi.com/apikey.aspx",
                yeslabel="Ir a Claves API", nolabel="Cancelar"):
                xbmc.executebuiltin("Container.Update({0})".format(_u(action='api_keys_menu')))
            return

        me_mode = mode if mode in ('movie', 'show') else 'movie'
        imdb_id = (ref or {}).get('imdb_id') if ref else None
        year    = (ref or {}).get('year') if ref else None
        clave_propia = bool(core_settings.get_omdb_user_key())

        import omdb as _omdb
        bg = xbmcgui.DialogProgressBG()
        bg.create("TopZilla", "Consultando OMDb...")
        try:
            if not imdb_id:
                try:
                    import metadata_enricher as me
                    meta = me.enrich(title=query, media_type=me_mode, year=year if year else None)
                    if meta:
                        imdb_id = (meta.get('ids') or {}).get('imdb')
                        if not year:
                            year = meta.get('year')
                except Exception:
                    pass
            data = _omdb.fetch(api_key, imdb_id=imdb_id, title=query, year=year, media_type=me_mode)
            primer_err = data.get('_topzilla_error') if isinstance(data, dict) else None
            if not clave_propia:
                ya_probadas = {api_key}
                while primer_err in ('invalid_key', 'rate_limit'):
                    core_settings.mark_omdb_pool_key_dead(api_key)
                    otra_clave = core_settings.get_omdb_api_key()
                    if not otra_clave or otra_clave in ya_probadas:
                        break
                    ya_probadas.add(otra_clave)
                    data = _omdb.fetch(otra_clave, imdb_id=imdb_id, title=query, year=year, media_type=me_mode)
                    api_key = otra_clave
                    primer_err = data.get('_topzilla_error') if isinstance(data, dict) else None
        finally:
            bg.close()

        err = data.get('_topzilla_error') if isinstance(data, dict) else None
        if err == 'invalid_key':
            xbmcgui.Dialog().ok(
                "OMDb",
                "La clave OMDb no es válida. Revisa Opciones → Claves API.")
            xbmcplugin.endOfDirectory(h, cacheToDisc=False)
            return
        if err == 'rate_limit':
            xbmcgui.Dialog().ok(
                "OMDb",
                "OMDb no está disponible ahora mismo. Inténtalo más tarde, "
                "o configura tu propia clave en Opciones → Claves API para mayor estabilidad.")
            xbmcplugin.endOfDirectory(h, cacheToDisc=False)
            return
        if err == 'network':
            xbmcgui.Dialog().ok("OMDb", "Sin conexión con OMDb. Comprueba tu acceso a Internet.")
            xbmcplugin.endOfDirectory(h, cacheToDisc=False)
            return
        if err == 'http':
            xbmcgui.Dialog().ok("OMDb", "Error en el servidor OMDb. Inténtalo más tarde.")
            xbmcplugin.endOfDirectory(h, cacheToDisc=False)
            return
        if not data:
            xbmcgui.Dialog().ok("OMDb", "No se encontraron datos para '{0}'.".format(query))
            xbmcplugin.endOfDirectory(h, cacheToDisc=False)
            return

        rt_val = mc_val = imdb_val = None
        ratings = data.get('Ratings')
        if not isinstance(ratings, list):
            ratings = []
        for rating in ratings:
            if not isinstance(rating, dict):
                continue
            source = rating.get('Source', '')
            value  = rating.get('Value', '')
            if value == 'N/A' or not value:
                continue
            if 'Rotten Tomatoes' in source:
                rt_val = value
            elif 'Metacritic' in source:
                mc_val = value
            elif 'Internet Movie Database' in source:
                imdb_val = value

        lines = []
        if imdb_val:
            lines.append("[COLOR gold][B]IMDb:[/B][/COLOR]              {0}".format(imdb_val))
        if rt_val:
            lines.append("[COLOR red][B]Rotten Tomatoes:[/B][/COLOR]   {0}".format(rt_val))
        if mc_val:
            lines.append("[COLOR yellow][B]Metacritic:[/B][/COLOR]        {0}".format(mc_val))

        imdb_votes = data.get('imdbVotes', '')
        if imdb_votes and imdb_votes != 'N/A':
            if lines:
                lines.append("")
            lines.append("[COLOR gray]({0} votos en IMDb)[/COLOR]".format(imdb_votes))

        title_omdb = data.get('Title')
        title_year = title_omdb if title_omdb and title_omdb != 'N/A' else query
        year_omdb = data.get('Year')
        if year_omdb and year_omdb != 'N/A':
            title_year = "{0} ({1})".format(title_year, year_omdb)

        if not lines:
            xbmcgui.Dialog().ok(
                "Críticas: {0}".format(title_year),
                "No hay puntuaciones disponibles en OMDb para esta película.")
        else:
            xbmcgui.Dialog().textviewer(
                "Críticas: {0}".format(title_year),
                "\n".join(lines))
        xbmcplugin.endOfDirectory(h, cacheToDisc=False)

    elif accion == "youtube":
        _search_youtube_from_results(query)
        xbmcplugin.endOfDirectory(h, cacheToDisc=False)

    elif accion == "soundtrack_yt":
        year = ''
        if ref and isinstance(ref, dict):
            y = ref.get('year') or 0
            if y:
                year = ' {0}'.format(y)
        yt_query = "{0}{1} soundtrack".format(query, year)
        xbmc.executebuiltin("Container.Update({0})".format(_u(action='yt_results', query=yt_query)))
        xbmcplugin.endOfDirectory(h, cacheToDisc=False)

    elif accion == "dailymotion_native":
        xbmc.executebuiltin("Container.Update({0})".format(_u(action='lfr', q=query, ot=ot, mode=mode)))
        xbmcplugin.endOfDirectory(h, cacheToDisc=False)

    elif accion == "wikipedia":
        # Cerrar la acción del plugin ANTES de abrir el flujo Wikipedia: así
        # no queda un contenedor intermedio en el historial. wikipedia_results
        # es un flujo de diálogos puro y vuelve al origen al cerrarse.
        xbmcplugin.endOfDirectory(h, succeeded=False, cacheToDisc=False)
        import search_movies as _sm
        _sm.wikipedia_results(query)
        return

    elif accion == "tmdb_extras":
        xbmcplugin.endOfDirectory(h, succeeded=False, cacheToDisc=False)
        import search_movies as _sm
        _sm.tmdb_extras_dialog(query,
            media_type=mode if mode in ('movie', 'show') else 'movie')
        return

    elif accion == "embuary_info":
        import context_menu as _cm
        if not _cm.has_embuary():
            xbmcplugin.endOfDirectory(h, succeeded=False, cacheToDisc=False)
            if xbmcgui.Dialog().yesno(
                "Embuary Info",
                "Embuary Info no está instalado.\n\n"
                "Instálalo para ver fichas detalladas (sinopsis ampliada, reparto, tráilers, recomendados...).",
                yeslabel="Instalar", nolabel="Cancelar"):
                xbmc.executebuiltin("InstallAddon(script.embuary.info)")
            return
        script = _cm._embuary_script(ref) if ref else None
        if not script:
            call_type = 'tv' if mode == 'show' else 'movie'
            safe = query.replace('"', ' ').replace(',', ' ').strip()
            if safe:
                script = "RunScript(script.embuary.info,call={0},query={1})".format(call_type, safe)
        xbmcplugin.endOfDirectory(h, succeeded=False, cacheToDisc=False)
        if script:
            xbmc.executebuiltin(script)
        return

    elif accion == "open_espadaily":
        params = {
            'action': 'search_alt_prompt',
            'q': query,
            'ot': ot or '',
        }
        if mode in ('movie', 'show'):
            params['mode'] = mode
        url = "plugin://plugin.video.espadaily/?" + urllib.parse.urlencode(params)
        xbmcplugin.endOfDirectory(h, succeeded=False, cacheToDisc=False)
        xbmc.executebuiltin('RunPlugin({0})'.format(url))
        return

    elif accion == "share_movie":
        me_mode = mode if mode in ('movie', 'show') else 'movie'
        title   = (ref.get('title') if ref else '') or query
        year    = (ref.get('year') if ref else 0) or 0
        tmdb_id = ref.get('tmdb_id') if ref else None
        rating  = None

        if not tmdb_id or not rating:
            try:
                import metadata_enricher as me
                meta = me.enrich(title=title, media_type=me_mode,
                                 year=year if year else None,
                                 tmdb_id=tmdb_id)
                if meta:
                    if not tmdb_id:
                        tmdb_id = (meta.get('ids') or {}).get('tmdb')
                    if not year:
                        year = meta.get('year') or 0
                    r = meta.get('rating') or 0
                    if r:
                        rating = round(float(r), 1)
            except Exception:
                pass

        header = '{0}'.format(title)
        if year:
            header += ' ({0})'.format(year)
        parts = [header]
        if rating:
            parts.append('{0}/10 (TMDB)'.format(rating))
        if tmdb_id:
            url_path = 'tv' if me_mode == 'show' else 'movie'
            parts.append('https://www.themoviedb.org/{0}/{1}'.format(url_path, tmdb_id))
        msg = '\n'.join(parts)

        if _copy_to_clipboard(msg):
            xbmcgui.Dialog().notification(
                'TopZilla', 'Mensaje copiado al portapapeles',
                xbmcgui.NOTIFICATION_INFO, 3000)
        else:
            xbmcgui.Dialog().textviewer('Compartir esta peli', msg)
        xbmcplugin.endOfDirectory(h, cacheToDisc=False)

    elif accion == "hint_shortcuts":
        xbmcplugin.endOfDirectory(h, succeeded=False, cacheToDisc=False)
        xbmc.executebuiltin("Container.Update({0})".format(_u(action='search_shortcuts_menu')))
        return

    elif accion.startswith("custom_"):
        try:
            sc_idx = int(accion.split("_", 1)[1])
        except (ValueError, IndexError):
            sc_idx = -1
        shortcuts = core_settings.load_search_shortcuts()
        if not (0 <= sc_idx < len(shortcuts)):
            xbmcplugin.endOfDirectory(h, cacheToDisc=False)
            return
        sc  = shortcuts[sc_idx]
        cmd = sc.get('command', '')
        if not cmd:
            xbmcplugin.endOfDirectory(h, cacheToDisc=False)
            return
        aid = sc.get('addon_id') or ''
        if aid and not xbmc.getCondVisibility('System.HasAddon({0})'.format(aid)):
            xbmcgui.Dialog().notification(
                'TopZilla',
                "El addon '{0}' no está instalado".format(aid),
                xbmcgui.NOTIFICATION_WARNING, 3000)
            xbmcplugin.endOfDirectory(h, cacheToDisc=False)
            return
        # Sustituye tokens. {query} = URL-encoded (para plugin:// y URLs).
        # {queryraw} = texto plano sin tocar (para RunScript, Notification...).
        cmd = cmd.replace('{query}', urllib.parse.quote(query, safe=''))
        cmd = cmd.replace('{queryraw}', query)
        xbmcplugin.endOfDirectory(h, succeeded=False, cacheToDisc=False)
        xbmc.executebuiltin(cmd)
        return

    else:
        xbmcplugin.endOfDirectory(h, cacheToDisc=False)


# YouTube scraping (sin API key)

def _yt_fetch_html(url, timeout=15):
    import urllib.request, gzip, io
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36",
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Accept-Language": "es-ES,es;q=0.9,en;q=0.8",
        "Accept-Encoding": "gzip, identity",
        "Cookie": "CONSENT=YES+1; SOCS=CAI",
    }
    req = urllib.request.Request(url, headers=headers)
    resp = urllib.request.urlopen(req, timeout=timeout)
    raw = resp.read()
    if (resp.headers.get("Content-Encoding") or "").lower() == "gzip":
        try:
            raw = gzip.GzipFile(fileobj=io.BytesIO(raw)).read()
        except OSError:
            pass
    return raw.decode("utf-8", errors="replace")


def _yt_parse_initial_data(html):
    import json as _json
    m = re.search(r'var ytInitialData\s*=\s*(\{.*?\});\s*</script>', html, re.DOTALL)
    if not m:
        m = re.search(r'ytInitialData"\]\s*=\s*(\{.*?\});', html, re.DOTALL)
    if not m:
        return None
    try:
        return _json.loads(m.group(1))
    except (ValueError, TypeError):
        return None


def _yt_parse_video_renderer(vr):
    vid = vr.get("videoId", "")
    if not vid or len(vid) != 11:
        return None
    title = ""
    try:
        runs = vr.get("title", {}).get("runs", [])
        title = runs[0].get("text", "") if runs else vr.get("title", {}).get("simpleText", "")
    except (KeyError, TypeError, IndexError):
        pass
    dur = ""
    try:
        dur = vr.get("lengthText", {}).get("simpleText", "") or ""
    except (KeyError, TypeError):
        pass
    channel = ""
    try:
        chan_runs = vr.get("ownerText", {}).get("runs", [])
        channel = chan_runs[0].get("text", "") if chan_runs else ""
    except (KeyError, TypeError, IndexError):
        pass
    views = ""
    try:
        views = (vr.get("viewCountText", {}).get("simpleText", "")
                 or vr.get("shortViewCountText", {}).get("simpleText", "") or "")
    except (KeyError, TypeError):
        pass
    published = ""
    try:
        published = vr.get("publishedTimeText", {}).get("simpleText", "") or ""
    except (KeyError, TypeError):
        pass
    return {"vid": vid, "title": title or "Video", "duration": dur,
            "channel": channel, "views": views, "published": published}


def _yt_extract_videos(data):
    try:
        sections = data["contents"]["twoColumnSearchResultsRenderer"]["primaryContents"]["sectionListRenderer"]["contents"]
    except (KeyError, TypeError):
        return []
    results = []
    for section in sections or []:
        if not isinstance(section, dict):
            continue
        isr = section.get("itemSectionRenderer")
        if not isr:
            continue
        for item in isr.get("contents", []):
            if not isinstance(item, dict):
                continue
            vr = item.get("videoRenderer")
            if vr:
                parsed = _yt_parse_video_renderer(vr)
                if parsed:
                    results.append(parsed)
    return results


def _yt_fallback_parse(html):
    import json as _json
    results = []
    seen = set()
    pattern = re.compile(
        r'"videoRenderer":\{"videoId":"([^"]{11})".*?"title":\{"runs":\[\{"text":"([^"]+)"\}',
        re.DOTALL,
    )
    for m in pattern.finditer(html):
        vid = m.group(1)
        try:
            title = _json.loads('"' + m.group(2) + '"')
        except (ValueError, TypeError):
            title = m.group(2)
        if vid not in seen:
            seen.add(vid)
            results.append({"vid": vid, "title": title, "duration": "", "channel": "", "views": "", "published": ""})
        if len(results) >= 20:
            break
    return results


def _search_youtube_from_results(query):
    if not query:
        return
    if not xbmc.getCondVisibility("System.HasAddon(plugin.video.youtube)"):
        xbmcgui.Dialog().ok("TopZilla",
            "El plugin de YouTube no está instalado.\n\n"
            "Instálalo desde el repositorio oficial de Kodi para reproducir los resultados.")
        return
    kb = xbmc.Keyboard(query, 'Buscar en YouTube')
    kb.doModal()
    if not kb.isConfirmed():
        return
    txt = (kb.getText() or "").strip()
    if not txt:
        return
    xbmc.executebuiltin("Container.Update({0})".format(_u(action='yt_results', query=txt)))


_YT_CACHE_TTL = 6 * 3600


def _yt_cache_path():
    profile = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    os.makedirs(profile, exist_ok=True)
    return os.path.join(profile, 'topzilla_yt_search_cache.json')


def _yt_cache_load():
    import json as _json
    import time as _time
    p = _yt_cache_path()
    if not os.path.exists(p):
        return {}
    try:
        with open(p, 'r', encoding='utf-8') as fh:
            data = _json.load(fh)
        if not isinstance(data, dict):
            return {}
        now = _time.time()
        return {k: v for k, v in data.items()
                if isinstance(v, dict) and (now - v.get('ts', 0)) < _YT_CACHE_TTL}
    except (OSError, ValueError):
        return {}


def _yt_cache_save(cache):
    import json as _json
    try:
        p = _yt_cache_path()
        tmp = p + '.tmp'
        with open(tmp, 'w', encoding='utf-8') as fh:
            _json.dump(cache, fh, ensure_ascii=False)
        os.replace(tmp, p)
    except OSError as e:
        xbmc.log("[TopZilla] yt cache save: {0}".format(e), xbmc.LOGWARNING)


def _yt_native_search_results(query):
    import time as _time
    h = int(sys.argv[1])
    query = (query or "").strip()
    if not query:
        xbmcplugin.endOfDirectory(h, succeeded=False)
        return

    cache = _yt_cache_load()
    cache_key = query.lower()
    entry = cache.get(cache_key)
    if entry and (_time.time() - entry.get('ts', 0)) < _YT_CACHE_TTL and entry.get('results'):
        results = entry['results']
    else:
        dp = xbmcgui.DialogProgress()
        dp.create("TopZilla", "Buscando en YouTube: {0}...".format(query))
        results = []
        try:
            encoded = urllib.parse.quote_plus(query)
            url = "https://www.youtube.com/results?search_query={0}".format(encoded)
            html = _yt_fetch_html(url)
            if dp.iscanceled():
                dp.close()
                xbmcplugin.endOfDirectory(h, succeeded=False)
                return
            dp.update(60)
            data = _yt_parse_initial_data(html)
            results = _yt_extract_videos(data) if data else []
            if not results:
                results = _yt_fallback_parse(html)
            dp.close()
        except (urllib.error.URLError, OSError, ValueError) as e:
            dp.close()
            xbmc.log("[TopZilla] Error buscando en YouTube: {0}".format(e), xbmc.LOGERROR)
            xbmcgui.Dialog().ok("TopZilla", "Error al buscar en YouTube:\n{0}".format(e))
            xbmcplugin.endOfDirectory(h, succeeded=False)
            return
        except Exception as e:
            dp.close()
            xbmc.log("[TopZilla] Error inesperado en YouTube: {0}".format(e), xbmc.LOGERROR)
            xbmcgui.Dialog().ok("TopZilla", "Error inesperado al buscar en YouTube:\n{0}".format(e))
            xbmcplugin.endOfDirectory(h, succeeded=False)
            return

        if results:
            cache[cache_key] = {'ts': _time.time(), 'results': results}
            _yt_cache_save(cache)

    if not results:
        xbmcgui.Dialog().ok("TopZilla", "No se encontraron resultados para:\n{0}".format(query))
        xbmcplugin.endOfDirectory(h, succeeded=False)
        return

    xbmcplugin.setContent(h, 'videos')
    for r in results:
        vid = r["vid"]
        title = r["title"]
        li = xbmcgui.ListItem(label=title)
        thumb = 'https://i.ytimg.com/vi/{0}/hqdefault.jpg'.format(vid)
        li.setArt({'icon': 'DefaultMusicVideos.png', 'thumb': thumb, 'poster': thumb, 'fanart': thumb})
        plot_lines = []
        if r.get("channel"):   plot_lines.append("Canal: {0}".format(r["channel"]))
        if r.get("duration"):  plot_lines.append("Duración: {0}".format(r["duration"]))
        if r.get("views"):     plot_lines.append("Vistas: {0}".format(r["views"]))
        if r.get("published"): plot_lines.append("Subido: {0}".format(r["published"]))
        li.setInfo('video', {'plot': "\n".join(plot_lines) or title, 'title': title, 'mediatype': 'video'})
        li.setProperty('IsPlayable', 'true')
        xbmcplugin.addDirectoryItem(handle=h,
            url="plugin://plugin.video.youtube/play/?video_id={0}".format(vid),
            listitem=li, isFolder=False)

    _bold  = core_settings.get_acc_force_bold()
    _strip = core_settings.get_acc_strip_symbols()
    _color = core_settings.get_acc_color_mode()
    li = xbmcgui.ListItem(label=core_settings.apply_label(
        "[COLOR yellow][B]Buscar otra cosa en YouTube...[/B][/COLOR]",
        bold=_bold, strip=_strip, color_mode=_color))
    li.setArt({'icon': 'DefaultAddonsSearch.png', 'fanart': core_settings.addon_fanart()})
    li.setInfo('video', {'plot': 'Muestra hasta 20 resultados. Prueba términos más específicos si no encuentras lo que buscas.'})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action='yt_results_kb'), listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(h, cacheToDisc=False)


def _yt_results_keyboard():
    h = int(sys.argv[1])
    kb = xbmc.Keyboard('', 'Buscar en YouTube')
    kb.doModal()
    if not kb.isConfirmed():
        xbmcplugin.endOfDirectory(h, succeeded=False)
        return
    txt = (kb.getText() or "").strip()
    if not txt:
        xbmcplugin.endOfDirectory(h, succeeded=False)
        return
    xbmc.executebuiltin("Container.Update({0})".format(_u(action='yt_results', query=txt)))


# Búsqueda nativa Dailymotion

def _dm_search_direct(q, extra_params=None):
    params = {
        "search": q,
        "fields": "id,title,owner.username,duration,thumbnail_360_url,thumbnail_720_url",
        "limit": 50,
    }
    if extra_params:
        params.update(extra_params)
    ua = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
    for verify in (True, False):
        try:
            r = requests.get(
                "https://api.dailymotion.com/videos",
                params=params,
                headers={"User-Agent": ua},
                timeout=15,
                verify=verify,
            )
            return r.json().get("list", [])
        except Exception:
            continue
    return []


def _sr(q, extra_params=None):
    return _dm_search_direct(q, extra_params or None)


def _clean_title(t):
    if " : " in t:
        parts = t.split(" : ")
        t = parts[1] if len(parts[1]) > len(parts[0]) else parts[0]
    return t.strip()


def _gsr(q, rs, mode=""):
    if not rs:
        return []
    sc = []
    ql = q.lower().strip()
    qn = re.findall(r'(\d+)', ql)
    for r in rs:
        t = r.get("title", "").strip()
        tl = t.lower()
        if not t:
            continue
        s = difflib.SequenceMatcher(None, ql, tl).ratio()
        q_words = [w for w in ql.split() if len(w) > 3]
        if q_words:
            matches = sum(1 for w in q_words if w in tl)
            if matches == 0:
                s -= 1.0
            elif matches < len(q_words):
                s -= 0.1
        if ql in tl:
            s += 0.35
        words_q = set(ql.split())
        words_t = set(tl.split())
        common = words_q.intersection(words_t)
        if common:
            s += (len(common) / len(words_q)) * 0.2
        tn = re.findall(r'(\d+)', tl)
        if qn and tn:
            if qn[-1] in tn:
                s += 0.4
            if set(qn).issubset(set(tn)):
                s += 0.1
        du = r.get("duration", 0)
        try:
            du = int(du)
        except (ValueError, TypeError):
            du = 0
        if s > 0.3:
            if du > 600:
                s += 0.6
            elif du > 300:
                s += 0.2
            if du < 180:
                s -= 0.1
        if any(w in tl for w in ["español", "castellano", "spanish"]):
            s += 0.15
        if mode == "movie":
            if any(w in tl for w in ["trailer", "avance", "entrevista", "making", "detras", "clip", "promo"]):
                s -= 0.5
            if any(w in tl for w in ["pelicula", "completa", "movie", "film"]):
                s += 0.2
        sc.append((min(s, 1.0), r))
    sc.sort(key=lambda x: x[0], reverse=True)
    return sc


def _lfd(q, ot, mode="", extra_params=None):
    cq = _clean_title(q)
    rs = []
    if mode == "movie":
        for v in [
            "{0} pelicula completa castellano".format(cq),
            "{0} pelicula completa español".format(cq),
            "{0} pelicula completa".format(cq),
            "{0} completa español".format(cq),
            "{0} castellano".format(cq),
            cq,
        ]:
            rs = _sr(v, extra_params)
            if rs:
                break
    else:
        rs = _sr(cq, extra_params)
        if not rs and cq != q:
            rs = _sr(q, extra_params)
    if not rs:
        kw = " ".join([w for w in re.findall(r'\w+', cq) if len(w) > 3])
        if kw:
            rs = _sr(kw, extra_params)

    h = int(sys.argv[1])
    _bold  = core_settings.get_acc_force_bold()
    _strip = core_settings.get_acc_strip_symbols()
    _color = core_settings.get_acc_color_mode()
    li_alt = xbmcgui.ListItem(label=core_settings.apply_label(
        "[COLOR yellow][B]¿No es lo que buscas? Editar o buscar en otro sitio[/B][/COLOR]",
        bold=_bold, strip=_strip, color_mode=_color))
    li_alt.setArt({'icon': 'DefaultAddonsSearch.png', 'fanart': core_settings.addon_fanart()})
    li_alt.setInfo('video', {'plot': "Edita la búsqueda o prueba en YouTube u otro addon."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="search_alt_prompt", q=cq, ot=ot), listitem=li_alt, isFolder=False)

    if not rs:
        xbmcgui.Dialog().notification("TopZilla", "No se encontraron resultados en Dailymotion", xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.endOfDirectory(h, cacheToDisc=False)
        return

    sr = _gsr(cq, rs, mode)[:25]
    if not sr:
        if xbmcgui.Dialog().yesno("TopZilla", "No se encontraron coincidencias relevantes.\n\n¿Quieres editar las palabras clave y probar otra vez?"):
            kb = xbmc.Keyboard(q, 'Editar Búsqueda')
            kb.doModal()
            if kb.isConfirmed() and kb.getText():
                xbmc.executebuiltin("Container.Update({0})".format(_u(action='lfr', q=kb.getText(), ot=ot)))
        xbmcplugin.endOfDirectory(h, cacheToDisc=False)
        return

    for sc, v in sr:
        vt = v.get("title", "Video")
        vi = v.get("id")
        ow = v.get("owner.username", "Unknown")
        du = v.get("duration", 0)
        try:
            du = int(du)
        except (ValueError, TypeError):
            du = 0
        dth = v.get("thumbnail_720_url") or v.get("thumbnail_360_url") or ot
        lb = vt if mode == "movie" else "{0} ({1}% match)".format(vt, int(sc * 100))
        li = xbmcgui.ListItem(label=lb)
        li.setArt({'thumb': dth, 'icon': dth, 'fanart': core_settings.addon_fanart()})
        li.setInfo('video', {'title': vt, 'plot': "Subido por: {0}\nDuración: {1}s".format(ow, du), 'duration': du})
        li.setProperty("IsPlayable", "true")
        xbmcplugin.addDirectoryItem(
            handle=h,
            url=_u(action="pv", vid=vi, title=urllib.parse.quote(vt)),
            listitem=li,
            isFolder=False,
        )
    xbmcplugin.endOfDirectory(h, cacheToDisc=False)


_UA_DM_DESKTOP = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
    "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36"
)
_HEADERS_DM_DESKTOP = {
    "User-Agent": _UA_DM_DESKTOP,
    "Origin": "https://www.dailymotion.com",
    "Referer": "https://www.dailymotion.com/",
}


def _fetch_hls_variants(master_url, headers=None):
    """Devuelve las variantes del master playlist HLS, ordenadas de mayor a menor bitrate."""
    from urllib.parse import urljoin
    variants = []
    try:
        r = requests.get(master_url, headers=headers or {}, timeout=15)
        if r.status_code != 200:
            return variants
        current_label = "unknown"
        current_bw = 0
        expecting_url = False
        for line in r.text.strip().splitlines():
            line = line.strip()
            if not line:
                continue
            if line.startswith('#EXT-X-STREAM-INF'):
                res_match = re.search(r'RESOLUTION=(\d+x\d+)', line)
                bw_match = re.search(r'BANDWIDTH=(\d+)', line)
                current_label = res_match.group(1) if res_match else "unknown"
                current_bw = int(bw_match.group(1)) if bw_match else 0
                expecting_url = True
            elif expecting_url and not line.startswith('#'):
                stream_url = line if line.startswith('http') else urljoin(master_url, line)
                variants.append({'label': current_label, 'url': stream_url, 'bandwidth': current_bw})
                expecting_url = False
        variants.sort(key=lambda x: x.get('bandwidth', 0), reverse=True)
    except (requests.RequestException, ValueError):
        pass
    return variants


def _dm_play_direct(vid, max_quality=1080):
    """Resolución directa via API de metadatos. URLs limpias sin headers pipe.
    Ideal para Android/Linux donde el reproductor nativo no acepta pipe headers.
    Devuelve {url, mime, subs} o None."""
    if not isinstance(vid, str) or not vid.strip():
        return None
    try:
        meta_url = "https://www.dailymotion.com/player/metadata/video/{0}".format(urllib.parse.quote(vid.strip()))
        r = requests.get(meta_url, headers=_HEADERS_DM_DESKTOP, timeout=15)
        if r.status_code != 200:
            xbmc.log("[TopZilla] _dm_play_direct HTTP: {0}".format(r.status_code), xbmc.LOGWARNING)
            return None
        data = r.json()
        if data.get("error"):
            xbmc.log("[TopZilla] DM API error: {0}".format(data["error"].get("message", "")), xbmc.LOGWARNING)
            return None

        qualities = data.get("qualities", {})
        subtitles = []
        subs_data = data.get("subtitles", {})
        if isinstance(subs_data, dict):
            for sub_list in subs_data.values():
                if isinstance(sub_list, list):
                    for sub in sub_list:
                        if isinstance(sub, dict) and sub.get("url"):
                            subtitles.append(sub["url"])

        # MP4 directo: mejor compatibilidad en Android que HLS.
        best_mp4, best_res = None, 0
        for res_key, formats in qualities.items():
            if res_key == "auto":
                continue
            try:
                res_val = int(res_key)
            except (ValueError, TypeError):
                continue
            if res_val > max_quality:
                continue
            for fmt in formats:
                if isinstance(fmt, dict) and fmt.get("type") == "video/mp4" and res_val > best_res:
                    best_mp4 = fmt.get("url")
                    best_res = res_val
        if best_mp4:
            xbmc.log("[TopZilla] _dm_play_direct MP4 {0}p".format(best_res), xbmc.LOGINFO)
            return {"url": best_mp4, "mime": "video/mp4", "subs": subtitles, "headers": _HEADERS_DM_DESKTOP}

        # Fallback HLS: _pv detecta mime mpegURL y configura inputstream.adaptive
        # con headers, lo que evita 403 al pedir segmentos.
        hls_url = None
        if "auto" in qualities:
            for item in qualities["auto"]:
                if isinstance(item, dict) and item.get("type") == "application/x-mpegURL":
                    hls_url = item.get("url")
                    break
        if hls_url:
            variants = _fetch_hls_variants(hls_url, headers=_HEADERS_DM_DESKTOP)
            if variants:
                filtered = []
                for v in variants:
                    label = v.get("label", "")
                    try:
                        height = int(label.split("x")[1].split(" ")[0]) if "x" in label else 0
                    except (ValueError, IndexError):
                        height = 0
                    if 0 < height <= max_quality:
                        filtered.append(v)
                target = filtered[0] if filtered else variants[-1]
                xbmc.log("[TopZilla] _dm_play_direct HLS variant", xbmc.LOGINFO)
                return {"url": target["url"], "mime": "application/x-mpegURL", "subs": subtitles, "headers": _HEADERS_DM_DESKTOP}
            xbmc.log("[TopZilla] _dm_play_direct HLS master", xbmc.LOGINFO)
            return {"url": hls_url, "mime": "application/x-mpegURL", "subs": subtitles, "headers": _HEADERS_DM_DESKTOP}
    except (requests.RequestException, ValueError) as exc:
        xbmc.log("[TopZilla] _dm_play_direct error: {0}".format(exc), xbmc.LOGERROR)
    return None


_DM_SYSPY_SCRIPT = r'''
import sys, json, re
try:
    import requests
    _GET = lambda u, h: requests.get(u, headers=h, timeout=15)
    _STATUS = lambda r: r.status_code
    _TEXT = lambda r: r.text
except ImportError:
    import urllib.request
    def _GET(u, h):
        return urllib.request.urlopen(urllib.request.Request(u, headers=h), timeout=15)
    _STATUS = lambda r: r.getcode()
    _TEXT = lambda r: r.read().decode()
vid = sys.argv[1]
hdr = {"User-Agent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36",
       "Origin":"https://www.dailymotion.com","Referer":"https://www.dailymotion.com/"}
r = _GET("https://www.dailymotion.com/player/metadata/video/"+vid, hdr)
if _STATUS(r) != 200:
    sys.exit(1)
data = json.loads(_TEXT(r))
if data.get("error"):
    sys.exit(2)
hls = ""
for it in data.get("qualities",{}).get("auto",[]):
    if it.get("type") == "application/x-mpegURL":
        hls = it.get("url",""); break
if not hls:
    sys.exit(3)
r2 = _GET(hls, hdr)
if _STATUS(r2) != 200:
    sys.exit(4)
master = _TEXT(r2)
m = re.findall(r"NAME=\"(\d+)\"[^\n]*\n([^\n]+)", master)
m.sort(key=lambda x: int(x[0]), reverse=True)
url = (m[0][1] if m else hls).split("#cell")[0]
print(json.dumps({"url": url}))
'''


def _pv(vid, title=""):
    """Reproduce un vídeo de Dailymotion.
    Cascada Windows: system-python -> yt-dlp -> directo -> dm_gujal -> navegador.
    Cascada Android: directo -> dm_gujal -> navegador."""
    h = int(sys.argv[1])
    dm_web_url = "https://www.dailymotion.com/video/{0}".format(vid)
    _is_windows = xbmc.getCondVisibility("System.Platform.Windows")

    _python_missing = False
    _ytdlp_missing = False

    if _is_windows:
        try:
            import subprocess, json as _json
            xbmcgui.Dialog().notification("TopZilla", "Resolviendo con Python sistema...", xbmcgui.NOTIFICATION_INFO, 2000)
            _proc = subprocess.run(
                ['python', '-c', _DM_SYSPY_SCRIPT, vid],
                capture_output=True, text=True, timeout=20,
                creationflags=0x08000000,
            )
            if _proc.returncode == 0 and _proc.stdout.strip():
                stream_url = _json.loads(_proc.stdout).get('url', '')
                if stream_url:
                    xbmc.log("[TopZilla] system-python OK", xbmc.LOGINFO)
                    li = xbmcgui.ListItem(label=title or vid, path=stream_url)
                    li.setMimeType('application/x-mpegURL')
                    li.setProperty('IsPlayable', 'true')
                    li.setContentLookup(False)
                    xbmcplugin.setResolvedUrl(h, True, li)
                    return
            xbmc.log("[TopZilla] system-python rc={0} err={1}".format(
                _proc.returncode, _proc.stderr[:200] if _proc.stderr else ''), xbmc.LOGWARNING)
        except FileNotFoundError:
            _python_missing = True
            xbmc.log("[TopZilla] system-python: python no encontrado en PATH", xbmc.LOGWARNING)
        except Exception as e:
            xbmc.log("[TopZilla] system-python fallido: {0}".format(e), xbmc.LOGWARNING)

    # Windows: yt-dlp vía subprocess cuando el script inline falla.
    # yt-dlp cubre más casos del extractor (cookies, geo-bypass, etc.).
    if _is_windows and not _python_missing:
        try:
            import subprocess, json as _json
            xbmcgui.Dialog().notification("TopZilla", "Resolviendo con yt-dlp...", xbmcgui.NOTIFICATION_INFO, 2000)
            _proc = subprocess.run(
                ['python', '-m', 'yt_dlp', '--dump-json', '--no-download',
                 '--format', 'best[ext=mp4]/best', '--no-playlist', dm_web_url],
                capture_output=True, text=True, timeout=30,
                creationflags=0x08000000,
            )
            if _proc.returncode == 0 and _proc.stdout.strip():
                stream_url = _json.loads(_proc.stdout).get('url', '')
                if stream_url:
                    xbmc.log("[TopZilla] yt-dlp OK", xbmc.LOGINFO)
                    li = xbmcgui.ListItem(label=title or vid, path=stream_url)
                    li.setProperty('IsPlayable', 'true')
                    li.setContentLookup(False)
                    xbmcplugin.setResolvedUrl(h, True, li)
                    return
            _err = (_proc.stderr or '') + (_proc.stdout or '')
            if 'No module named' in _err and 'yt_dlp' in _err:
                _ytdlp_missing = True
            xbmc.log("[TopZilla] yt-dlp sin URL", xbmc.LOGWARNING)
        except FileNotFoundError:
            _python_missing = True
        except Exception as e:
            xbmc.log("[TopZilla] yt-dlp fallido: {0}".format(e), xbmc.LOGWARNING)

    if _is_windows and (_python_missing or _ytdlp_missing):
        if _python_missing:
            _msg = "Instala Python y yt-dlp para reproducción fiable en Windows"
        else:
            _msg = "Instala yt-dlp (pip install yt-dlp) para reproducción más fiable"
        xbmcgui.Dialog().notification("TopZilla - Dailymotion", _msg, xbmcgui.NOTIFICATION_INFO, 6000)

    # API directa. Si HLS -> inputstream.adaptive con headers
    # (Kodi propaga UA/Origin/Referer al manifiesto y a los segmentos).
    result = _dm_play_direct(vid)
    if result:
        url_val = result.get("url")
        if isinstance(url_val, str) and url_val:
            mime_val = result.get("mime") or "application/x-mpegURL"
            subs_val = result.get("subs")
            headers_dict = result.get("headers") or {}
            is_hls = "mpegURL" in mime_val
            header_str = ""
            if isinstance(headers_dict, dict) and headers_dict:
                header_str = "&".join(
                    "{0}={1}".format(k, urllib.parse.quote(str(v)))
                    for k, v in headers_dict.items()
                )

            stream_url = url_val
            if not is_hls and header_str:
                stream_url = "{0}|{1}".format(url_val, header_str)

            li = xbmcgui.ListItem(label=title or vid, path=stream_url)
            li.setMimeType(mime_val)
            li.setContentLookup(False)
            if is_hls and header_str:
                li.setProperty("inputstream", "inputstream.adaptive")
                li.setProperty("inputstream.adaptive.manifest_type", "hls")
                li.setProperty("inputstream.adaptive.manifest_headers", header_str)
                li.setProperty("inputstream.adaptive.stream_headers", header_str)
            if isinstance(subs_val, list) and subs_val:
                li.setSubtitles(subs_val)
            xbmcplugin.setResolvedUrl(h, True, li)
            return

    # dm_gujal (extreme → basic, headers en pipe).
    try:
        import dm_gujal
        url, subs, mime = dm_gujal.play_dm_extreme(vid)
        if not url:
            url, mime = dm_gujal.play_dm_basic(vid)
            subs = []
        if url:
            li = xbmcgui.ListItem(label=title or vid, path=url)
            li.setMimeType(mime or 'application/x-mpegURL')
            li.setContentLookup(False)
            if subs:
                li.setSubtitles(subs)
            xbmcplugin.setResolvedUrl(h, True, li)
            return
    except Exception as e:
        xbmc.log("[TopZilla] DM: dm_gujal fallido: {0}".format(e), xbmc.LOGWARNING)

    # Último recurso: abrir el vídeo en el navegador web.
    if xbmcgui.Dialog().yesno(
        "TopZilla - Dailymotion",
        "No se pudo reproducir en Kodi.\n\n"
        "¿Quieres abrir el vídeo en el navegador web?",
        yeslabel="Navegador", nolabel="Cancelar",
    ):
        try:
            import webbrowser
            webbrowser.open(dm_web_url)
            xbmcgui.Dialog().notification("TopZilla", "Enlace enviado al navegador", xbmcgui.NOTIFICATION_INFO, 2000)
        except Exception:
            xbmcgui.Dialog().ok("TopZilla", "Abre esta URL en tu navegador:\n\n{0}".format(dm_web_url))
    else:
        xbmcgui.Dialog().notification("TopZilla", "No se encontró stream válido", xbmcgui.NOTIFICATION_ERROR)
    try:
        xbmcplugin.setResolvedUrl(h, False, xbmcgui.ListItem())
    except Exception:
        pass


def _run():
    stats.ping()
    params = dict(urllib.parse.parse_qsl(sys.argv[2].lstrip('?')))
    a = params.get('action', '')

    if not a:
        _main_menu()

    elif a == "filmaffinity_menu":
        import filmaffinity
        filmaffinity.menu()
    elif a == "filmaffinity_list":
        import filmaffinity
        filmaffinity.show_list(params.get("genre", ""))
    elif a == "filmaffinity_submenu":
        h = int(sys.argv[1])
        _bold  = core_settings.get_acc_force_bold()
        _strip = core_settings.get_acc_strip_symbols()
        _color = core_settings.get_acc_color_mode()
        for label, action, plot in [
            ("En Cines España",            "filmaffinity_cartelera", "Películas en cines en España según FilmAffinity."),
            ("Top Valoradas (TMDB)",       "filmaffinity_top",       "Las películas mejor valoradas según TMDB."),
            ("Top FilmAffinity (Comunidad)","filmaffinity_topfa",    "Las mejores películas según los usuarios de FilmAffinity."),
        ]:
            li = xbmcgui.ListItem(label=core_settings.apply_label("[B]{0}[/B]".format(label), bold=_bold, strip=_strip, color_mode=_color))
            li.setArt({'icon': 'DefaultVideoPlaylists.png', 'fanart': core_settings.addon_fanart()})
            li.setInfo('video', {'plot': plot})
            xbmcplugin.addDirectoryItem(handle=h, url=_u(action=action), listitem=li, isFolder=True)
        xbmcplugin.endOfDirectory(h, cacheToDisc=False)
    elif a == "filmaffinity_cartelera":
        import filmaffinity
        filmaffinity.show_cartelera()
    elif a == "filmaffinity_top":
        import filmaffinity
        filmaffinity.show_top()
    elif a == "filmaffinity_topfa":
        import filmaffinity
        filmaffinity.show_topfa()
    elif a == "filmaffinity_cache_cartelera_meta":
        import filmaffinity
        filmaffinity.cache_cartelera_meta()
    elif a == "filmaffinity_clear_cartelera_meta":
        import filmaffinity
        filmaffinity.clear_cartelera_meta()

    elif a == "sensacine_submenu":
        h = int(sys.argv[1])
        _bold  = core_settings.get_acc_force_bold()
        _strip = core_settings.get_acc_strip_symbols()
        _color = core_settings.get_acc_color_mode()
        for label, action, plot in [
            ("En Cartelera",      "sensacine_menu",       "Películas en cines según SensaCine."),
            ("Estrenos",          "sensacine_estrenos",   "Últimos estrenos según SensaCine."),
            ("Mejores Películas", "sensacine_mejores",    "Las mejores películas de todos los tiempos según los usuarios de SensaCine."),
            ("Taquilla",          "sensacine_taquilla",   "Las películas más vistas en taquilla actualmente."),
        ]:
            li = xbmcgui.ListItem(label=core_settings.apply_label("[B]{0}[/B]".format(label), bold=_bold, strip=_strip, color_mode=_color))
            li.setArt({'icon': 'DefaultVideoPlaylists.png', 'fanart': core_settings.addon_fanart()})
            li.setInfo('video', {'plot': plot})
            xbmcplugin.addDirectoryItem(handle=h, url=_u(action=action), listitem=li, isFolder=True)
        xbmcplugin.endOfDirectory(h, cacheToDisc=False)
    elif a == "sensacine_menu":
        import sensacine
        sensacine.show_cartelera()
    elif a == "sensacine_estrenos":
        import sensacine
        sensacine.show_estrenos()
    elif a == "sensacine_mejores":
        import sensacine
        sensacine.show_mejores()
    elif a == "sensacine_taquilla":
        import sensacine
        sensacine.show_taquilla()
    elif a == "sensacine_cache_cartelera_meta":
        import sensacine
        sensacine.cache_cartelera_meta()
    elif a == "sensacine_clear_cartelera_meta":
        import sensacine
        sensacine.clear_cartelera_meta()
    elif a == "sensacine_cache_estrenos_meta":
        import sensacine
        sensacine.cache_estrenos_meta()
    elif a == "sensacine_clear_estrenos_meta":
        import sensacine
        sensacine.clear_estrenos_meta()
    elif a == "sensacine_cache_mejores_meta":
        import sensacine
        sensacine.cache_mejores_meta()
    elif a == "sensacine_clear_mejores_meta":
        import sensacine
        sensacine.clear_mejores_meta()
    elif a == "sensacine_cache_taquilla_meta":
        import sensacine
        sensacine.cache_taquilla_meta()
    elif a == "sensacine_clear_taquilla_meta":
        import sensacine
        sensacine.clear_taquilla_meta()

    elif a == "cinemeta_submenu":
        h = int(sys.argv[1])
        _bold  = core_settings.get_acc_force_bold()
        _strip = core_settings.get_acc_strip_symbols()
        _color = core_settings.get_acc_color_mode()
        for label, action, plot in [
            ("Top Películas", "cinemeta_top",          "Las películas más populares según Cinemeta/Stremio (~190 títulos)."),
            ("Por Género",    "cinemeta_genres_menu",  "Películas top filtradas por género."),
        ]:
            li = xbmcgui.ListItem(label=core_settings.apply_label("[B]{0}[/B]".format(label), bold=_bold, strip=_strip, color_mode=_color))
            li.setArt({'icon': 'DefaultVideoPlaylists.png', 'fanart': core_settings.addon_fanart()})
            li.setInfo('video', {'plot': plot})
            xbmcplugin.addDirectoryItem(handle=h, url=_u(action=action), listitem=li, isFolder=True)
        xbmcplugin.endOfDirectory(h, cacheToDisc=False)
    elif a == "cinemeta_top":
        import cinemeta
        cinemeta.show_top()
    elif a == "cinemeta_genres_menu":
        import cinemeta
        cinemeta.show_genres_menu()
    elif a == "cinemeta_genre":
        import cinemeta
        cinemeta.show_genre(params.get("slug", ""))
    elif a == "cinemeta_cache_meta":
        import cinemeta
        cinemeta.cache_meta()
    elif a == "cinemeta_clear_meta":
        import cinemeta
        cinemeta.clear_meta()

    elif a == "tmdb_lists_menu":
        import tmdb_lists
        tmdb_lists.show_menu()
    elif a == "tmdb_lists_show":
        import tmdb_lists
        tmdb_lists.show_list(params.get("endpoint", ""), params.get("media_type", "movie"), params.get("page", 1))

    elif a == "on_air_calendar":
        import on_air_calendar
        on_air_calendar.show_calendar()
    elif a == "on_air_calendar_refresh":
        import on_air_calendar
        on_air_calendar.refresh()

    elif a == "top_movies":
        import top_movies
        top_movies.show_top(params.get("page", 1))
    elif a == "cache_top_movies_covers":
        import top_movies
        top_movies.cache_covers()
    elif a == "clear_top_movies_cache":
        import top_movies
        top_movies.clear_cache()

    elif a == "oscar_movies":
        import oscar_movies
        oscar_movies.show_oscar(params.get("page", 1))
    elif a == "cache_oscar_movies_covers":
        import oscar_movies
        oscar_movies.cache_covers()
    elif a == "clear_oscar_movies_cache":
        import oscar_movies
        oscar_movies.clear_cache()

    elif a == "options_menu":
        _options_menu()
    elif a == "open_addon_settings":
        import xbmcaddon
        xbmcaddon.Addon().openSettings()
        xbmc.executebuiltin("Container.Refresh")
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
    elif a == "toggle_auto_fetch":
        new_val = not core_settings._auto_fetch_enabled()
        if core_settings.set_auto_fetch_enabled(new_val):
            msg = "ACTIVADA" if new_val else "DESACTIVADA"
            xbmcgui.Dialog().notification("TopZilla", "Enriquecimiento con TMDB {0}.".format(msg), xbmcgui.NOTIFICATION_INFO, 3000)
        else:
            xbmcgui.Dialog().notification("TopZilla", "No se pudo guardar el ajuste.", xbmcgui.NOTIFICATION_ERROR, 3000)
        xbmc.executebuiltin("Container.Refresh")
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
    elif a == "toggle_show_context_menu":
        new_val = not core_settings._show_context_menu_enabled()
        if core_settings.set_show_context_menu_enabled(new_val):
            msg = "ACTIVADA" if new_val else "DESACTIVADA"
            xbmcgui.Dialog().notification("TopZilla", "Opción en menú contextual {0}.".format(msg), xbmcgui.NOTIFICATION_INFO, 3000)
        else:
            xbmcgui.Dialog().notification("TopZilla", "No se pudo guardar el ajuste.", xbmcgui.NOTIFICATION_ERROR, 3000)
        xbmc.executebuiltin("Container.Refresh")
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
    elif a == "toggle_show_context_menu_view_card":
        new_val = not core_settings._show_context_menu_view_card_enabled()
        if core_settings.set_show_context_menu_view_card_enabled(new_val):
            msg = "ACTIVADA" if new_val else "DESACTIVADA"
            xbmcgui.Dialog().notification("TopZilla", "«Ver ficha» en menú contextual {0}.".format(msg), xbmcgui.NOTIFICATION_INFO, 3000)
        else:
            xbmcgui.Dialog().notification("TopZilla", "No se pudo guardar el ajuste.", xbmcgui.NOTIFICATION_ERROR, 3000)
        xbmc.executebuiltin("Container.Refresh")
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
    elif a == "fanart_menu":
        _fanart_menu()
    elif a == "fanart_cycle_mode":
        _fanart_cycle_mode()
    elif a == "fanart_browse_custom":
        _fanart_browse_custom()

    elif a == "api_keys_menu":
        _api_keys_menu()
    elif a == "api_key_set_tmdb":
        _api_key_set_tmdb()
    elif a == "api_key_set_trakt":
        _api_key_set_trakt()
    elif a == "api_key_set_omdb":
        _api_key_set_omdb()

    elif a == "accessibility_menu":
        _accessibility_menu()
    elif a == "acc_set_color":
        _acc_set_color()
    elif a == "acc_toggle_bold":
        _acc_toggle_bold()
    elif a == "acc_toggle_symbols":
        _acc_toggle_symbols()
    elif a == "acc_toggle_font_size":
        _acc_toggle_font_size()
    elif a == "cleanup_menu":
        _cleanup_menu()
    elif a == "cleanup_caches":
        _cleanup_caches()
    elif a == "vacuum_metadata_db":
        _vacuum_metadata_db()
    elif a == "delete_metadata_db":
        _delete_metadata_db()
    elif a == "factory_reset":
        _factory_reset()

    elif a == "search_shortcuts_menu":
        _search_shortcuts_menu()
    elif a == "search_shortcut_add_addon":
        _search_shortcut_add_addon()
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
    elif a == "search_shortcut_add_manual":
        _search_shortcut_add_manual()
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
    elif a == "search_shortcut_add_favourite":
        _search_shortcut_add_favourite()
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
    elif a == "search_shortcut_remove":
        try:
            _search_shortcut_remove(int(params.get('idx', -1)))
        except (ValueError, TypeError):
            pass
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
    elif a == "search_shortcut_rename":
        try:
            _search_shortcut_rename(int(params.get('idx', -1)))
        except (ValueError, TypeError):
            pass
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
    elif a == "search_shortcut_actions":
        try:
            _search_shortcut_actions(int(params.get('idx', -1)))
        except (ValueError, TypeError):
            pass
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
    elif a == "search_menu_reorder":
        _search_menu_reorder()
        xbmcplugin.endOfDirectory(int(sys.argv[1]), succeeded=False, cacheToDisc=False)
    elif a == "toggle_espadaily_integration":
        _toggle_espadaily_integration()
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
    elif a == "toggle_soundtrack_button":
        new_state = not core_settings.show_soundtrack_button_enabled()
        core_settings.set_show_soundtrack_button_enabled(new_state)
        msg = "Botón Banda Sonora: " + ("ACTIVADO" if new_state else "DESACTIVADO")
        xbmcgui.Dialog().notification("TopZilla", msg, xbmcgui.NOTIFICATION_INFO, 2000)
        xbmc.executebuiltin("Container.Refresh")
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
    elif a == "toggle_omdb_button":
        new_state = not core_settings.show_omdb_button_enabled()
        core_settings.set_show_omdb_button_enabled(new_state)
        msg = "Botón Críticas OMDb: " + ("ACTIVADO" if new_state else "DESACTIVADO")
        xbmcgui.Dialog().notification("TopZilla", msg, xbmcgui.NOTIFICATION_INFO, 2000)
        xbmc.executebuiltin("Container.Refresh")
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
    elif a == "toggle_share_button":
        new_state = not core_settings.show_share_button_enabled()
        core_settings.set_show_share_button_enabled(new_state)
        msg = "Botón Compartir: " + ("ACTIVADO" if new_state else "DESACTIVADO")
        xbmcgui.Dialog().notification("TopZilla", msg, xbmcgui.NOTIFICATION_INFO, 2000)
        xbmc.executebuiltin("Container.Refresh")
        xbmcplugin.endOfDirectory(int(sys.argv[1]))

    elif a == "search_alt_prompt":
        import movie_ref as _mr
        _search_alternatives_prompt(params.get("q", ""), params.get("ot", ""), params.get("mode", ""),
                                    ref=_mr.loads_ref(params.get("ref", "")) or None)

    elif a == "record_navigation":
        import movie_ref
        import navigation_history
        ref = movie_ref.loads_ref(params.get('ref', ''))
        navigation_history.record(ref)
        _search_alternatives_prompt(
            ref.get('title', ''),
            ref.get('poster', ''),
            ref.get('media_type', 'movie'),
            ref=ref,
        )

    elif a == "show_card_from_context":
        import movie_ref
        ref = movie_ref.loads_ref(params.get('ref', ''))
        if ref and ref.get('title'):
            _search_alternatives_prompt(
                ref.get('title', ''),
                ref.get('poster', ''),
                ref.get('media_type', 'movie'),
                ref=ref,
            )

    elif a == "search_menu":
        import search_movies
        search_movies.show_search_menu()
    elif a == "search_query":
        import search_movies
        search_movies.perform_search(params.get('q') or None)
    elif a == "search_history_menu":
        import search_movies
        search_movies.show_history()
    elif a == "search_history_delete":
        import search_movies
        search_movies.delete_history_entry(params.get('q', ''))
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
    elif a == "search_history_clear":
        import search_movies
        search_movies.clear_history()
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
    elif a == "search_youtube_prompt":
        h = int(sys.argv[1])
        # Cerramos el directorio vacío SIEMPRE (succeeded=True para que Kodi
        # no lo trate como error). Después Container.Update,replace cambia
        # el container al listado real, dejando una sola entrada en el
        # historial para que el botón atrás vuelva al menú padre.
        xbmcplugin.endOfDirectory(h, succeeded=True, cacheToDisc=False)
        if not xbmc.getCondVisibility("System.HasAddon(plugin.video.youtube)"):
            xbmcgui.Dialog().ok("TopZilla",
                "El plugin de YouTube no está instalado.\n\n"
                "Instálalo desde el repositorio oficial de Kodi.")
        else:
            kb = xbmc.Keyboard('', 'Buscar en YouTube...')
            kb.doModal()
            if kb.isConfirmed():
                q = kb.getText().strip()
                if q:
                    import search_movies
                    search_movies._add_to_history(q)
                    xbmc.executebuiltin("Container.Update({0},replace)".format(
                        _u(action='yt_results', query=q)))
    elif a == "search_dailymotion_prompt":
        h = int(sys.argv[1])
        xbmcplugin.endOfDirectory(h, succeeded=True, cacheToDisc=False)
        kb = xbmc.Keyboard('', 'Buscar en Dailymotion...')
        kb.doModal()
        if kb.isConfirmed():
            q = kb.getText().strip()
            if q:
                import search_movies
                search_movies._add_to_history(q)
                xbmc.executebuiltin("Container.Update({0},replace)".format(
                    _u(action='lfr', q=q)))

    elif a == "search_wikipedia_prompt":
        h = int(sys.argv[1])
        xbmcplugin.endOfDirectory(h, succeeded=False, cacheToDisc=False)
        kb = xbmc.Keyboard('', 'Buscar en Wikipedia...')
        kb.doModal()
        if kb.isConfirmed():
            q = kb.getText().strip()
            if q:
                import search_movies
                search_movies._add_to_history(q)
                search_movies.wikipedia_results(q)

    elif a == "wikipedia_results":
        # Compatibilidad: si algo aún invoca esta acción por URL, la cerramos
        # y delegamos al flujo de diálogos.
        h = int(sys.argv[1])
        xbmcplugin.endOfDirectory(h, succeeded=False, cacheToDisc=False)
        import search_movies
        search_movies.wikipedia_results(params.get('query', ''))

    elif a == "explore_cache_menu":
        import search_movies
        search_movies.show_explore_menu()
    elif a == "explore_cache_by":
        import search_movies
        search_movies.show_explore_values(params.get('field', ''))
    elif a == "explore_cache_filter":
        import search_movies
        search_movies.show_explore_results(params.get('field', ''),
                                            params.get('value', ''))

    elif a == "my_library_menu":
        _my_library_menu()

    elif a == "favorites_menu":
        import favorites
        favorites.show_menu()
    elif a == "add_favorite":
        import favorites, movie_ref
        ref = movie_ref.loads_ref(params.get('ref', ''))
        favorites.add(ref)
    elif a == "remove_favorite":
        import favorites
        favorites.remove(params.get('key', ''))
    elif a == "edit_favorite":
        import favorites
        favorites.edit(params.get('key', ''))
    elif a == "favorites_edit_menu":
        import favorites
        favorites.show_edit_menu()
    elif a == "favorite_pick_action":
        import favorites
        favorites.pick_action(params.get('key', ''))
    elif a == "favorites_clear_all":
        import favorites
        favorites.clear_all()
    elif a == "flowfav_launch":
        import espakodi_installer
        espakodi_installer.launch_by_id("plugin.program.flowfavmanager")

    elif a == "categories_menu":
        import category_manager
        category_manager.main_menu()
    elif a == "cat_create":
        import category_manager
        category_manager.create_category()
    elif a == "cat_delete":
        import category_manager
        category_manager.delete_category(params.get('name', ''))
    elif a == "cat_rename":
        import category_manager
        category_manager.rename_category(params.get('name', ''))
    elif a == "cat_view":
        import category_manager
        category_manager.view_category(params.get('name', ''))
    elif a == "cat_remove_item":
        import category_manager
        category_manager.remove_item(params.get('cat', ''), params.get('key', ''))
    elif a == "cat_move_item":
        import category_manager
        category_manager.move_item(params.get('from_cat', ''), params.get('key', ''))
    elif a == "cat_backup_menu":
        import category_manager
        category_manager.backup_menu()
    elif a == "cat_export":
        import category_manager
        category_manager.export_categories()
    elif a == "cat_import":
        import category_manager
        category_manager.import_categories()

    elif a == "watch_history_menu":
        import watch_history
        watch_history.show_menu()

    elif a == "navigation_history_menu":
        import navigation_history
        navigation_history.show_menu()
    elif a == "navigation_history_delete":
        import navigation_history
        navigation_history.delete(params.get('key', ''))
    elif a == "navigation_history_clear_all":
        import navigation_history
        navigation_history.clear_all()

    elif a == "trakt_root":
        import trakt_manager
        trakt_manager.menu_trakt_root()
    elif a == "trakt_options":
        import trakt_manager
        trakt_manager.menu_options()
    elif a == "trakt_help_guide":
        import trakt_manager
        trakt_manager.help_guide()
    elif a == "trakt_set_key":
        import trakt_manager
        trakt_manager.set_api_key()
    elif a == "trakt_import":
        import trakt_manager
        trakt_manager.import_list()
    elif a == "trakt_lists_reorder":
        _trakt_lists_reorder()
    elif a == "trakt_view_list":
        import trakt_manager
        trakt_manager.view_list(params.get('list_id', ''))
    elif a == "trakt_delete_list":
        import trakt_manager
        trakt_manager.delete_list(params.get('list_id', ''))
    elif a == "trakt_refresh_defaults":
        import trakt_manager
        trakt_manager.refresh_all_lists()
    elif a == "trakt_cache_covers":
        import trakt_manager
        trakt_manager.cache_covers(params.get('list_id', ''))
    elif a == "trakt_clear_cache":
        import trakt_manager
        trakt_manager.clear_cache(params.get('list_id', ''))
    elif a == "trakt_cache_all_meta":
        import trakt_manager
        trakt_manager.cache_all_meta()
    elif a == "trakt_clear_all_meta":
        import trakt_manager
        trakt_manager.clear_all_meta()

    elif a == "backup_menu":
        import backup_manager
        backup_manager.show_menu()
    elif a == "backup_create":
        import backup_manager
        backup_manager.create_backup()
    elif a == "backup_list":
        import backup_manager
        backup_manager.list_backups()
    elif a == "backup_restore":
        import backup_manager
        backup_manager.restore_backup(params.get('path', ''))
    elif a == "backup_restore_external":
        import backup_manager
        backup_manager.restore_external()
    elif a == "backup_delete":
        import backup_manager
        backup_manager.delete_backup(params.get('path', ''))
    elif a == "backup_delete_all":
        import backup_manager
        backup_manager.delete_all_backups()
    elif a == "backup_set_dir":
        import backup_manager
        backup_manager.choose_backup_dir()

    elif a == "mark_watched":
        import watch_history, movie_ref
        ref = movie_ref.loads_ref(params.get('ref', ''))
        watch_history.mark(ref)

    elif a == "unmark_watched":
        import watch_history
        watch_history.unmark(params.get('key', ''))

    elif a == "watch_history_clear_all":
        import watch_history
        watch_history.clear_all()

    elif a == "cat_add_item":
        import category_manager, movie_ref
        ref = movie_ref.loads_ref(params.get('ref', ''))
        category_manager.add_item_dialog(ref)

    elif a == "info_menu":
        info_menu()

    elif a == "espakodi_addons_menu":
        import espakodi_installer
        espakodi_installer.render_menu(int(sys.argv[1]))

    elif a == "ek_launch":
        import espakodi_installer
        espakodi_installer.launch_by_id(params.get("addon_id", ""))

    elif a == "check_repo_status":
        import espakodi_installer
        espakodi_installer.check_repo_status()

    elif a == "show_universo":
        import universo; universo.show()

    elif a == "info":
        _info()

    elif a == "vpn_info":
        xbmcgui.Dialog().ok(
            "La VPN puede causar fallos o ser necesaria",
            "Algunos servidores bloquean VPNs (desactívala si algo no carga).\n\n"
            "En Dailymotion puede ocurrir lo contrario, si no carga prueba activando la VPN."
        )

    elif a == "future_i18n_info":
        xbmcgui.Dialog().ok(
            "Próximamente: más países e idiomas",
            "Este addon se adaptará a más países y contará con más idiomas en futuras versiones."
        )

    elif a == "noop":
        pass

    elif a == "yt_results":
        _yt_native_search_results(params.get('query', ''))

    elif a == "yt_results_kb":
        _yt_results_keyboard()

    elif a == "lfr":
        _lfd(params.get('q', ''), params.get('ot', ''), params.get('mode', ''))

    elif a == "pv":
        _pv(params.get('vid', ''), urllib.parse.unquote(params.get('title', '')))

    else:
        xbmc.log("[TopZilla] acción desconocida: {0}".format(a), xbmc.LOGWARNING)
        xbmcplugin.endOfDirectory(int(sys.argv[1]))


if __name__ == '__main__':
    _run()
