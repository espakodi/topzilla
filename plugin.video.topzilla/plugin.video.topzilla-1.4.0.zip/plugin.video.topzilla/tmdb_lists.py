# -*- coding: utf-8 -*-
# TopZilla — Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/espatv)
# Consulta el archivo LICENSE para mas detalles.
"""Listas curadas de películas vía API de TMDB."""
import json
import os
import sys
import time

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

import core_settings

_IMG_W342   = "https://image.tmdb.org/t/p/w342"
_IMG_ORIG   = "https://image.tmdb.org/t/p/original"
_TTL        = 6 * 3600
_PAGE_SIZE  = 20

_TMDB_GENRE_NAMES = {
    28: "Acción", 12: "Aventura", 16: "Animación", 35: "Comedia", 80: "Crimen",
    99: "Documental", 18: "Drama", 10751: "Familia", 14: "Fantasía",
    36: "Historia", 27: "Terror", 10402: "Música", 9648: "Misterio",
    10749: "Romance", 878: "Ciencia ficción", 10770: "TV", 53: "Suspense",
    10752: "Bélica", 37: "Western",
    10759: "Acción y aventura", 10762: "Infantil", 10763: "Noticias",
    10764: "Reality", 10765: "Ciencia ficción y fantasía",
    10766: "Telenovela", 10767: "Talk show", 10768: "Bélica y política",
}


def _genres_from_ids(ids):
    if not ids:
        return ""
    names = [_TMDB_GENRE_NAMES.get(g) for g in ids[:3]]
    return ", ".join([n for n in names if n])

_LISTS = [
    ("Top valoradas de todos los tiempos", "movie/top_rated",        "movie"),
    ("Populares ahora",                    "movie/popular",           "movie"),
    ("Tendencias hoy",                     "trending/movie/day",      "movie"),
    ("Tendencias esta semana",             "trending/movie/week",     "movie"),
    ("En cines ahora",                     "movie/now_playing",       "movie"),
    ("Próximos estrenos",                  "movie/upcoming",          "movie"),
    ("Mejores series TV",                  "tv/top_rated",            "show"),
    ("Series populares",                   "tv/popular",              "show"),
    ("Tendencias series esta semana",      "trending/tv/week",        "show"),
    ("Series en emisión",                  "tv/on_the_air",           "show"),
    ("Series que emiten hoy",              "tv/airing_today",         "show"),
]


def _u(**kwargs):
    return core_settings.make_url(**kwargs)

def _handle():
    return int(sys.argv[1])


def _api_key():
    return core_settings.get_tmdb_api_key()


def _cache_path():
    profile = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    return os.path.join(profile, 'topzilla_tmdb_lists_cache.json')


def _load_cache():
    try:
        p = _cache_path()
        if not os.path.exists(p):
            return {}
        with open(p, 'r', encoding='utf-8') as fh:
            data = json.load(fh)
        return data if isinstance(data, dict) else {}
    except (OSError, ValueError):
        return {}


def _save_cache(data):
    try:
        p = _cache_path()
        os.makedirs(os.path.dirname(p), exist_ok=True)
        tmp = p + '.tmp'
        with open(tmp, 'w', encoding='utf-8') as fh:
            json.dump(data, fh, ensure_ascii=False)
        os.replace(tmp, p)
    except OSError as e:
        xbmc.log("[TopZilla-TL] cache save: {0}".format(e), xbmc.LOGWARNING)


def _tmdb_get(path, params=None):
    if not _api_key():
        return None
    import metadata_enricher as me
    return me.tmdb_get(path, dict(params or {}, language='es-ES'))


def _fetch_page(endpoint, media_type, page=1):
    cache = _load_cache()
    cache_key = "{0}|{1}".format(endpoint, page)
    entry = cache.get(cache_key, {})
    if entry and (time.time() - entry.get('ts', 0)) < _TTL:
        return entry['items']

    data = _tmdb_get(endpoint, {'page': page})
    if not data:
        return []

    results = data.get('results') or []
    items = []
    for r in results:
        if media_type == 'show':
            title = r.get('name') or r.get('original_name', '')
            year  = (r.get('first_air_date') or '')[:4]
        else:
            title = r.get('title') or r.get('original_title', '')
            year  = (r.get('release_date') or '')[:4]
        if not title:
            continue
        poster_path = r.get('poster_path') or ''
        items.append({
            'tmdb_id':    str(r.get('id', '')),
            'title':      title,
            'year':       year,
            'plot':       r.get('overview', ''),
            'rating':     r.get('vote_average', 0),
            'genre':      _genres_from_ids(r.get('genre_ids') or []),
            'poster':     "{0}{1}".format(_IMG_W342, poster_path) if poster_path else '',
            'fanart':     "{0}{1}".format(_IMG_ORIG, r.get('backdrop_path', '')) if r.get('backdrop_path') else '',
            'media_type': media_type,
        })

    total_pages = data.get('total_pages', 1)
    cache[cache_key] = {'ts': time.time(), 'items': items, 'total_pages': total_pages}
    _save_cache(cache)
    return items


def _get_total_pages(endpoint, page):
    cache = _load_cache()
    cache_key = "{0}|{1}".format(endpoint, page)
    entry = cache.get(cache_key, {})
    return entry.get('total_pages', 1)


def show_menu():
    h = _handle()
    if not _api_key():
        li = xbmcgui.ListItem(label="[COLOR red]Configura la API key de TMDB en los ajustes del addon[/COLOR]")
        li.setArt({'icon': 'DefaultIconError.png', 'fanart': core_settings.addon_fanart()})
        xbmcplugin.addDirectoryItem(handle=h, url='', listitem=li, isFolder=False)
        xbmcplugin.endOfDirectory(h)
        return

    _bold  = core_settings.get_acc_force_bold()
    _strip = core_settings.get_acc_strip_symbols()
    _color = core_settings.get_acc_color_mode()
    for label, endpoint, media_type in _LISTS:
        li = xbmcgui.ListItem(label=core_settings.apply_label("[B]{0}[/B]".format(label), bold=_bold, strip=_strip, color_mode=_color))
        li.setArt({'icon': 'DefaultVideoPlaylists.png', 'fanart': core_settings.addon_fanart()})
        xbmcplugin.addDirectoryItem(
            handle=h,
            url=_u(action='tmdb_lists_show', endpoint=endpoint, media_type=media_type, page=1),
            listitem=li,
            isFolder=True,
        )
    xbmcplugin.endOfDirectory(h)


def show_list(endpoint, media_type, page=1):
    import metadata_enricher as me

    h = _handle()
    page = int(page)
    items = _fetch_page(endpoint, media_type, page)
    if not items:
        xbmcgui.Dialog().notification("TopZilla", "No se pudo cargar la lista de TMDB", xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.endOfDirectory(h)
        return

    af = core_settings.addon_fanart()

    import context_menu, movie_ref
    _bold  = core_settings.get_acc_force_bold()
    _strip = core_settings.get_acc_strip_symbols()
    _color = core_settings.get_acc_color_mode()

    # En la primera página de "Series en emisión" añade un acceso al
    # calendario agregado de los próximos episodios. Consume datos cacheados
    # 6 h, así que no impacta a la API key salvo regeneración explícita.
    if media_type == 'show' and page == 1:
        cal_li = xbmcgui.ListItem(label=core_settings.apply_label(
            "[COLOR limegreen][B]Ver calendario de emisión (próximos 14 días)[/B][/COLOR]",
            bold=_bold, strip=_strip, color_mode=_color))
        cal_li.setArt({'icon': 'DefaultRecentlyAddedEpisodes.png', 'fanart': core_settings.addon_fanart()})
        cal_li.setInfo('video', {'plot':
            "Episodios programados en los próximos 14 días para las series "
            "actualmente en emisión, agrupados por día.\n\n"
            "Datos cacheados durante 6 horas para no saturar la API de TMDB."})
        xbmcplugin.addDirectoryItem(
            handle=h,
            url=_u(action='on_air_calendar'),
            listitem=cal_li,
            isFolder=True,
        )

    for item in items:
        year_int = int(item['year']) if item.get('year', '').isdigit() else 0
        rating   = item.get('rating', 0)
        label    = "[B]{0}[/B]".format("{0} ({1})".format(item['title'], year_int) if year_int else item['title'])
        li = xbmcgui.ListItem(label=core_settings.apply_label(label, bold=_bold, strip=_strip, color_mode=_color))

        meta = me.enrich(
            tmdb_id=item['tmdb_id'],
            title=item['title'],
            year=year_int or None,
            media_type=media_type,
            use_cache_only=not core_settings._auto_fetch_enabled(),
        )
        if meta:
            me.apply_to_listitem(li, meta, addon_fanart=af)
            poster = meta.get('poster') or item['poster']
        else:
            art = {'icon': 'DefaultVideo.png'}
            if item['poster']:
                art.update({'thumb': item['poster'], 'poster': item['poster']})
            art['fanart'] = item['fanart'] or af
            li.setArt(art)
            header = me.build_plot_header(rating, item.get('genre'))
            info = {
                'title':     item['title'],
                'plot':      header + (item['plot'] or ''),
                'mediatype': 'tvshow' if media_type == 'show' else 'movie',
            }
            if year_int:
                info['year'] = year_int
            if rating:
                info['rating'] = rating
            if item.get('genre'):
                info['genre'] = item['genre']
            li.setInfo('video', info)
            poster = item['poster']

        plot = meta.get('overview', '') if meta else item.get('plot', '')
        ref = movie_ref.make_ref(
            title=item['title'], year=year_int,
            tmdb_id=item['tmdb_id'], poster=poster,
            media_type=media_type, source='tmdb', plot=plot,
        )
        context_menu.attach(li, ref)
        li.setProperty('IsPlayable', 'false')
        xbmcplugin.addDirectoryItem(handle=h, url=context_menu.build_play_url(ref), listitem=li, isFolder=False)

    total_pages = _get_total_pages(endpoint, page)
    if page < total_pages:
        li = xbmcgui.ListItem(label=core_settings.apply_label("[COLOR limegreen][B]Página siguiente ({0}/{1})[/B][/COLOR]".format(page + 1, total_pages), bold=_bold, strip=_strip, color_mode=_color))
        li.setArt({'icon': 'DefaultFolder.png', 'fanart': core_settings.addon_fanart()})
        xbmcplugin.addDirectoryItem(
            handle=h,
            url=_u(action='tmdb_lists_show', endpoint=endpoint, media_type=media_type, page=page + 1),
            listitem=li,
            isFolder=True,
        )

    xbmcplugin.endOfDirectory(h)
